# WordPress MySQL database migration
#
# Generated: Sunday 31. January 2016 02:19 UTC
# Hostname: localhost
# Database: `cp_leonrov`
# --------------------------------------------------------

/*!40101 SET NAMES utf8 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `cp_cf7dbplugin_st`
#

DROP TABLE IF EXISTS `cp_cf7dbplugin_st`;


#
# Table structure of table `cp_cf7dbplugin_st`
#

CREATE TABLE `cp_cf7dbplugin_st` (
  `submit_time` decimal(16,4) NOT NULL,
  PRIMARY KEY (`submit_time`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `cp_cf7dbplugin_st`
#
INSERT INTO `cp_cf7dbplugin_st` ( `submit_time`) VALUES
('1423585107.1884') ;

#
# End of data contents of table `cp_cf7dbplugin_st`
# --------------------------------------------------------



#
# Delete any existing table `cp_cf7dbplugin_submits`
#

DROP TABLE IF EXISTS `cp_cf7dbplugin_submits`;


#
# Table structure of table `cp_cf7dbplugin_submits`
#

CREATE TABLE `cp_cf7dbplugin_submits` (
  `submit_time` decimal(16,4) NOT NULL,
  `form_name` varchar(127) CHARACTER SET utf8 DEFAULT NULL,
  `field_name` varchar(127) CHARACTER SET utf8 DEFAULT NULL,
  `field_value` longtext CHARACTER SET utf8,
  `field_order` int(11) DEFAULT NULL,
  `file` longblob,
  KEY `submit_time_idx` (`submit_time`),
  KEY `form_name_idx` (`form_name`),
  KEY `field_name_idx` (`field_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;


#
# Data contents of table `cp_cf7dbplugin_submits`
#
INSERT INTO `cp_cf7dbplugin_submits` ( `submit_time`, `form_name`, `field_name`, `field_value`, `field_order`, `file`) VALUES
('1423585107.1884', 'Formulario Contacto', 'email_to', 'cristian@rotrer.com', 0, NULL),
('1423585107.1884', 'Formulario Contacto', 'name_to', 'Webmaster', 1, NULL),
('1423585107.1884', 'Formulario Contacto', 'from_name', 'Cristian', 2, NULL),
('1423585107.1884', 'Formulario Contacto', 'from_email', 'cristian.alvarado.donoso@gmail.com', 3, NULL),
('1423585107.1884', 'Formulario Contacto', 'subject', 'Carolina Parsons Contact: Hola', 4, NULL),
('1423585107.1884', 'Formulario Contacto', 'message', 'lorem ipsun', 5, NULL),
('1423585107.1884', 'Formulario Contacto', 'date_time', '10/02/2015 ', 6, NULL),
('1423585107.1884', 'Formulario Contacto', 'ip_address', '127.0.0.1', 7, NULL),
('1423585107.1884', 'Formulario Contacto', 'full_message', 'To:\nWebmaster\n\nNombre\nCristian\n\nEmail:\ncristian.alvarado.donoso@gmail.com\n\nAsunto\nHola\n\nMensaje\nlorem ipsun\n\nFrom a WordPress user: admin\nUser email: cristian@rotrer.com\nUser display name: admin\nSent from (ip address): 127.0.0.1 (localhost)\nDate/Time: 10/02/2015 \nComing from (referer): http://dev.parsons.app/?page_id=40\nUsing (user agent): Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/40.0.2214.111 Safari/537.36\n\n', 8, NULL),
('1423585107.1884', 'Formulario Contacto', 'Submitted Login', 'admin', 9999, NULL),
('1423585107.1884', 'Formulario Contacto', 'Submitted From', '127.0.0.1', 10000, NULL) ;

#
# End of data contents of table `cp_cf7dbplugin_submits`
# --------------------------------------------------------



#
# Delete any existing table `cp_cntctfrm_field`
#

DROP TABLE IF EXISTS `cp_cntctfrm_field`;


#
# Table structure of table `cp_cntctfrm_field`
#

CREATE TABLE `cp_cntctfrm_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` char(100) NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;


#
# Data contents of table `cp_cntctfrm_field`
#
INSERT INTO `cp_cntctfrm_field` ( `id`, `name`) VALUES
(1, 'name'),
(2, 'email'),
(3, 'subject'),
(4, 'message'),
(5, 'address'),
(6, 'phone'),
(7, 'attachment'),
(8, 'attachment_explanations'),
(9, 'send_copy'),
(10, 'sent_from'),
(11, 'date_time'),
(12, 'coming_from'),
(13, 'user_agent') ;

#
# End of data contents of table `cp_cntctfrm_field`
# --------------------------------------------------------



#
# Delete any existing table `cp_commentmeta`
#

DROP TABLE IF EXISTS `cp_commentmeta`;


#
# Table structure of table `cp_commentmeta`
#

CREATE TABLE `cp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_commentmeta`
#

#
# End of data contents of table `cp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `cp_comments`
#

DROP TABLE IF EXISTS `cp_comments`;


#
# Table structure of table `cp_comments`
#

CREATE TABLE `cp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_comments`
#
INSERT INTO `cp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(2, 24, 'Leo', 'leonrov@gmail.com', '', '186.37.202.64', '2015-02-12 17:07:35', '2015-02-12 20:07:35', 'hola', 0, 'post-trashed', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:35.0) Gecko/20100101 Firefox/35.0', '', 0, 0),
(3, 24, 'leo', 'leonrov@gmail.com', '', '186.37.202.64', '2015-02-12 17:08:16', '2015-02-12 20:08:16', 'test2', 0, 'post-trashed', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:35.0) Gecko/20100101 Firefox/35.0', '', 0, 0),
(4, 24, 'Leo', 'leonrov@gmail.com', '', '186.37.202.64', '2015-02-12 17:08:47', '2015-02-12 20:08:47', 'Comentario', 0, 'post-trashed', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:35.0) Gecko/20100101 Firefox/35.0', '', 0, 0) ;

#
# End of data contents of table `cp_comments`
# --------------------------------------------------------



#
# Delete any existing table `cp_links`
#

DROP TABLE IF EXISTS `cp_links`;


#
# Table structure of table `cp_links`
#

CREATE TABLE `cp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_links`
#

#
# End of data contents of table `cp_links`
# --------------------------------------------------------



#
# Delete any existing table `cp_options`
#

DROP TABLE IF EXISTS `cp_options`;


#
# Table structure of table `cp_options`
#

CREATE TABLE `cp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=3752 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_options`
#
INSERT INTO `cp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://dev.parsons.app/wp', 'yes'),
(2, 'home', 'http://dev.parsons.app', 'yes'),
(3, 'blogname', 'Carolina Parsons', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'cristian@rotrer.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '200', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '', 'yes'),
(22, 'posts_per_page', '200', 'yes'),
(23, 'date_format', 'd/m/Y', 'yes'),
(24, 'time_format', '', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '1', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'gzipcompression', '0', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:7:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:27:"clone-posts/clone-posts.php";i:2;s:58:"contact-form-7-to-database-extension/contact-form-7-db.php";i:3;s:31:"easy-post-types/custom-type.php";i:5;s:37:"post-types-order/post-types-order.php";i:6;s:47:"regenerate-thumbnails/regenerate-thumbnails.php";i:9;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'advanced_edit', '0', 'yes'),
(37, 'comment_max_links', '2', 'yes'),
(38, 'gmt_offset', '-3', 'yes'),
(39, 'default_email_category', '1', 'yes'),
(40, 'recently_edited', 'a:4:{i:0;s:80:"cp.localhost:8888/wp-content/plugins/social-share-button/social-share-button.php";i:1;s:71:"cp.localhost:8888/wp-content/plugins/advanced-custom-fields-pro/acf.php";i:2;s:48:"cp.localhost:8888/wp-content/themes/cp/style.css";i:3;s:0:"";}', 'no'),
(41, 'template', 'cp', 'yes'),
(42, 'stylesheet', 'cp', 'yes'),
(43, 'comment_whitelist', '', 'yes'),
(44, 'blacklist_keys', '', 'no'),
(45, 'comment_registration', '', 'yes'),
(46, 'html_type', 'text/html', 'yes'),
(47, 'use_trackback', '0', 'yes'),
(48, 'default_role', 'subscriber', 'yes'),
(49, 'db_version', '30133', 'yes'),
(50, 'uploads_use_yearmonth_folders', '', 'yes'),
(51, 'upload_path', '', 'yes'),
(52, 'blog_public', '0', 'yes'),
(53, 'default_link_category', '2', 'yes'),
(54, 'show_on_front', 'posts', 'yes'),
(55, 'tag_base', '', 'yes'),
(56, 'show_avatars', '', 'yes'),
(57, 'avatar_rating', 'G', 'yes'),
(58, 'upload_url_path', '', 'yes'),
(59, 'thumbnail_size_w', '0', 'yes'),
(60, 'thumbnail_size_h', '0', 'yes'),
(61, 'thumbnail_crop', '', 'yes'),
(62, 'medium_size_w', '0', 'yes'),
(63, 'medium_size_h', '0', 'yes'),
(64, 'avatar_default', 'mystery', 'yes'),
(65, 'large_size_w', '0', 'yes'),
(66, 'large_size_h', '0', 'yes'),
(67, 'image_default_link_type', '', 'yes'),
(68, 'image_default_size', '', 'yes'),
(69, 'image_default_align', '', 'yes'),
(70, 'close_comments_for_old_posts', '', 'yes'),
(71, 'close_comments_days_old', '14', 'yes'),
(72, 'thread_comments', '1', 'yes'),
(73, 'thread_comments_depth', '5', 'yes'),
(74, 'page_comments', '', 'yes'),
(75, 'comments_per_page', '50', 'yes'),
(76, 'default_comments_page', 'newest', 'yes'),
(77, 'comment_order', 'asc', 'yes'),
(78, 'sticky_posts', 'a:0:{}', 'yes'),
(79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_text', 'a:0:{}', 'yes'),
(81, 'widget_rss', 'a:0:{}', 'yes'),
(82, 'uninstall_plugins', 'a:2:{s:36:"contact-form-plugin/contact_form.php";s:23:"cntctfrm_delete_options";s:43:"social-share-button/social-share-button.php";s:13:"ssb_uninstall";}', 'no'),
(83, 'timezone_string', '', 'yes'),
(84, 'page_for_posts', '0', 'yes'),
(85, 'page_on_front', '0', 'yes'),
(86, 'default_post_format', '0', 'yes'),
(87, 'link_manager_enabled', '0', 'yes'),
(88, 'initial_db_version', '30133', 'yes'),
(89, 'cp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(90, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(91, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(92, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(93, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"orphaned_widgets_1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(96, 'cron', 'a:5:{i:1454224380;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1454245074;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1454245112;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1454271209;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(136, 'WPLANG', 'es_CL', 'yes'),
(139, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1423166922;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(140, 'current_theme', 'Parsons', 'yes'),
(141, 'theme_mods_cp', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:11:"header-menu";i:7;}}', 'yes') ;
INSERT INTO `cp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(142, 'theme_switched', '', 'yes'),
(143, 'recently_activated', 'a:3:{s:50:"hero-themes-gallery-manager/ht-gallery-manager.php";i:1454191829;s:45:"ultimate-social-deux/ultimate-social-deux.php";i:1454191806;s:35:"si-contact-form/si-contact-form.php";i:1454191782;}', 'yes'),
(149, 'acf_version', '5.1.3', 'yes'),
(162, 'options_fotos_slider_home_0_foto_silder_home', '8', 'no'),
(163, '_options_fotos_slider_home_0_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(164, 'options_fotos_slider_home_0_', '', 'no'),
(165, '_options_fotos_slider_home_0_', 'field_54d3d0000dd42', 'no'),
(166, 'options_fotos_slider_home_1_foto_silder_home', '9', 'no'),
(167, '_options_fotos_slider_home_1_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(168, 'options_fotos_slider_home_1_', '', 'no'),
(169, '_options_fotos_slider_home_1_', 'field_54d3d0000dd42', 'no'),
(170, 'options_fotos_slider_home_2_foto_silder_home', '10', 'no'),
(171, '_options_fotos_slider_home_2_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(172, 'options_fotos_slider_home_2_', '', 'no'),
(173, '_options_fotos_slider_home_2_', 'field_54d3d0000dd42', 'no'),
(174, 'options_fotos_slider_home_3_foto_silder_home', '11', 'no'),
(175, '_options_fotos_slider_home_3_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(176, 'options_fotos_slider_home_3_', '', 'no'),
(177, '_options_fotos_slider_home_3_', 'field_54d3d0000dd42', 'no'),
(178, 'options_fotos_slider_home_4_foto_silder_home', '12', 'no'),
(179, '_options_fotos_slider_home_4_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(182, 'options_fotos_slider_home_5_foto_silder_home', '13', 'no'),
(183, '_options_fotos_slider_home_5_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(186, 'options_fotos_slider_home_6_foto_silder_home', '14', 'no'),
(187, '_options_fotos_slider_home_6_foto_silder_home', 'field_54d3cfb70dd41', 'no'),
(190, 'options_fotos_slider_home', '4', 'no'),
(191, '_options_fotos_slider_home', 'field_54d3cf560dd40', 'no'),
(225, 'options_fotos_slider_home_0_foto_slider_h', '363', 'no'),
(226, '_options_fotos_slider_home_0_foto_slider_h', 'field_54d3cfb70dd41', 'no'),
(227, 'options_fotos_slider_home_1_foto_slider_h', '358', 'no'),
(228, '_options_fotos_slider_home_1_foto_slider_h', 'field_54d3cfb70dd41', 'no'),
(229, 'options_fotos_slider_home_2_foto_slider_h', '359', 'no'),
(230, '_options_fotos_slider_home_2_foto_slider_h', 'field_54d3cfb70dd41', 'no'),
(231, 'options_fotos_slider_home_3_foto_slider_h', '357', 'no'),
(232, '_options_fotos_slider_home_3_foto_slider_h', 'field_54d3cfb70dd41', 'no'),
(291, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(397, 'bstwbsftwppdtplgns_options', 'a:1:{s:8:"bws_menu";a:1:{s:7:"version";a:1:{s:36:"contact-form-plugin/contact_form.php";s:5:"1.4.0";}}}', 'yes'),
(399, 'fs_contact_global', 'a:11:{s:12:"fscf_version";s:6:"4.0.32";s:7:"donated";s:5:"false";s:18:"vcita_auto_install";s:5:"false";s:13:"vcita_dismiss";s:5:"false";s:17:"vcita_initialized";s:5:"false";s:22:"vcita_show_disable_msg";s:5:"false";s:10:"vcita_site";s:13:"www.vcita.com";s:19:"enable_php_sessions";s:5:"false";s:19:"num_standard_fields";s:1:"4";s:12:"max_form_num";i:3;s:9:"form_list";a:3:{i:1;s:8:"New Form";i:2;s:8:"New Form";i:3;s:8:"New Form";}}', 'yes'),
(401, 'fs_contact_form1', 'a:167:{s:9:"form_name";s:8:"New Form";s:7:"welcome";s:41:"<p>Comments or questions are welcome.</p>";s:8:"email_to";s:29:"Webmaster,cristian@rotrer.com";s:9:"email_bcc";s:0:"";s:13:"email_subject";s:25:"Carolina Parsons Contact:";s:10:"email_from";s:0:"";s:14:"email_reply_to";s:0:"";s:6:"fields";a:4:{i:0;a:21:{s:8:"standard";s:1:"1";s:6:"delete";s:5:"false";s:5:"label";s:5:"Name:";s:4:"type";s:4:"text";s:4:"slug";s:9:"full_name";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:1;a:21:{s:8:"standard";s:1:"2";s:6:"delete";s:5:"false";s:5:"label";s:6:"Email:";s:4:"type";s:4:"text";s:4:"slug";s:5:"email";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:2;a:21:{s:8:"standard";s:1:"3";s:6:"delete";s:5:"false";s:5:"label";s:8:"Subject:";s:4:"type";s:4:"text";s:4:"slug";s:7:"subject";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:3;a:21:{s:8:"standard";s:1:"4";s:6:"delete";s:5:"false";s:5:"label";s:8:"Message:";s:4:"type";s:8:"textarea";s:4:"slug";s:7:"message";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}}s:11:"name_format";s:4:"name";s:16:"auto_fill_enable";s:4:"true";s:11:"date_format";s:10:"mm/dd/yyyy";s:13:"cal_start_day";s:1:"0";s:11:"time_format";s:2:"12";s:12:"attach_types";s:33:"doc,docx,pdf,txt,gif,jpg,jpeg,png";s:11:"attach_size";s:3:"1mb";s:12:"title_border";s:12:"Contact Form";s:14:"external_style";s:5:"false";s:10:"form_style";s:27:"width:99%; max-width:555px;";s:14:"left_box_style";s:39:"float:left; width:55%; max-width:270px;";s:15:"right_box_style";s:24:"float:left; width:235px;";s:11:"clear_style";s:11:"clear:both;";s:16:"field_left_style";s:70:"clear:left; float:left; width:99%; max-width:550px; margin-right:10px;";s:18:"field_follow_style";s:58:"float:left; padding-left:10px; width:99%; max-width:250px;";s:21:"field_prefollow_style";s:70:"clear:left; float:left; width:99%; max-width:250px; margin-right:10px;";s:11:"title_style";s:33:"text-align:left; padding-top:5px;";s:15:"field_div_style";s:16:"text-align:left;";s:20:"captcha_div_style_sm";s:41:"width:80px; height:50px; padding-top:2px;";s:19:"captcha_div_style_m";s:42:"width:120px; height:65px; padding-top:2px;";s:19:"captcha_image_style";s:72:"border-style:none; margin:0; padding:0px; padding-right:5px; float:left;";s:26:"captcha_reload_image_style";s:64:"border-style:none; margin:0; padding:0px; vertical-align:bottom;";s:16:"submit_div_style";s:46:"text-align:left; clear:both; padding-top:15px;";s:12:"border_style";s:65:"border:1px solid black; width:99%; max-width:550px; padding:10px;";s:14:"required_style";s:16:"text-align:left;";s:19:"required_text_style";s:16:"text-align:left;";s:10:"hint_style";s:38:"font-size:x-small; font-weight:normal;";s:11:"error_style";s:27:"text-align:left; color:red;";s:14:"redirect_style";s:16:"text-align:left;";s:14:"fieldset_style";s:65:"border:1px solid black; width:97%; max-width:500px; padding:10px;";s:11:"label_style";s:16:"text-align:left;";s:18:"option_label_style";s:15:"display:inline;";s:11:"field_style";s:54:"text-align:left; margin:0; width:99%; max-width:250px;";s:19:"captcha_input_style";s:39:"text-align:left; margin:0; width:100px;";s:14:"textarea_style";s:68:"text-align:left; margin:0; width:99%; max-width:250px; height:120px;";s:12:"select_style";s:16:"text-align:left;";s:14:"checkbox_style";s:11:"width:13px;";s:11:"radio_style";s:11:"width:13px;";s:17:"placeholder_style";s:27:"opacity:0.6; color:#333333;";s:12:"button_style";s:25:"cursor:pointer; margin:0;";s:11:"reset_style";s:25:"cursor:pointer; margin:0;";s:18:"vcita_button_style";s:156:"text-decoration:none; display:block; text-align:center; background:linear-gradient(to bottom, #ed6a31 0%, #e55627 100%); color:#fff !important; padding:8px;";s:22:"vcita_div_button_style";s:63:"border-left:1px dashed #ccc; margin-top:25px; padding:8px 20px;";s:16:"powered_by_style";s:74:"font-size:x-small; font-weight:normal; padding-top:5px; text-align:center;";s:22:"req_field_label_enable";s:4:"true";s:16:"tooltip_required";s:0:"";s:26:"req_field_indicator_enable";s:4:"true";s:19:"req_field_indicator";s:1:"*";s:10:"title_dept";s:0:"";s:12:"title_select";s:0:"";s:10:"title_name";s:0:"";s:11:"title_fname";s:0:"";s:11:"title_lname";s:0:"";s:11:"title_mname";s:0:"";s:12:"title_miname";s:0:"";s:11:"title_email";s:0:"";s:12:"title_email2";s:0:"";s:10:"title_subj";s:0:"";s:10:"title_mess";s:0:"";s:10:"title_capt";s:0:"";s:12:"title_submit";s:0:"";s:16:"title_submitting";s:0:"";s:11:"title_reset";s:0:"";s:16:"title_areyousure";s:0:"";s:17:"text_message_sent";s:0:"";s:17:"text_print_button";s:0:"";s:15:"tooltip_captcha";s:0:"";s:15:"tooltip_refresh";s:0:"";s:17:"tooltip_filetypes";s:0:"";s:16:"tooltip_filesize";s:0:"";s:13:"error_correct";s:0:"";s:20:"error_contact_select";s:0:"";s:13:"error_subject";s:0:"";s:10:"error_name";s:0:"";s:11:"error_field";s:0:"";s:12:"error_select";s:0:"";s:11:"error_email";s:0:"";s:17:"error_email_check";s:0:"";s:12:"error_email2";s:0:"";s:9:"error_url";s:0:"";s:10:"error_date";s:0:"";s:10:"error_time";s:0:"";s:12:"error_maxlen";s:0:"";s:19:"error_captcha_blank";s:0:"";s:19:"error_captcha_wrong";s:0:"";s:13:"error_spambot";s:0:"";s:11:"error_input";s:0:"";s:14:"captcha_enable";s:4:"true";s:13:"captcha_small";s:4:"true";s:18:"captcha_perm_level";s:4:"read";s:19:"akismet_send_anyway";s:4:"true";s:14:"domain_protect";s:4:"true";s:20:"domain_protect_names";s:0:"";s:22:"auto_respond_from_name";s:16:"Carolina Parsons";s:23:"auto_respond_from_email";s:19:"cristian@rotrer.com";s:21:"auto_respond_reply_to";s:19:"cristian@rotrer.com";s:20:"auto_respond_subject";s:0:"";s:20:"auto_respond_message";s:0:"";s:15:"redirect_enable";s:4:"true";s:16:"redirect_seconds";i:3;s:12:"redirect_url";s:22:"http://dev.parsons.app";s:15:"redirect_ignore";s:0:"";s:15:"redirect_rename";s:0:"";s:12:"redirect_add";s:0:"";s:17:"submit_attributes";s:0:"";s:15:"form_attributes";s:0:"";s:13:"anchor_enable";s:4:"true";s:22:"enable_submit_oneclick";s:4:"true";s:15:"after_form_note";s:0:"";s:17:"success_page_html";s:0:"";s:17:"php_mailer_enable";s:9:"wordpress";s:18:"sender_info_enable";s:4:"true";s:11:"silent_send";s:3:"off";s:10:"silent_url";s:0:"";s:13:"silent_ignore";s:0:"";s:13:"silent_rename";s:0:"";s:10:"silent_add";s:0:"";s:24:"silent_conditional_field";s:0:"";s:24:"silent_conditional_value";s:0:"";s:13:"export_ignore";s:0:"";s:13:"export_rename";s:0:"";s:10:"export_add";s:0:"";s:14:"vcita_approved";s:5:"false";s:9:"vcita_uid";s:0:"";s:11:"vcita_email";s:0:"";s:15:"vcita_email_new";s:19:"cristian@rotrer.com";s:16:"vcita_first_name";s:0:"";s:15:"vcita_last_name";s:0:"";s:29:"vcita_scheduling_button_label";s:23:"Schedule an Appointment";s:26:"vcita_scheduling_link_text";s:68:"Click above to schedule an appointment using vCita Online Scheduling";s:19:"email_from_enforced";s:5:"false";s:21:"preserve_space_enable";s:5:"false";s:12:"double_email";s:5:"false";s:16:"name_case_enable";s:5:"false";s:15:"email_check_dns";s:5:"false";s:16:"email_check_easy";s:5:"false";s:10:"email_html";s:5:"false";s:15:"akismet_disable";s:5:"false";s:16:"email_hide_empty";s:5:"false";s:22:"email_keep_attachments";s:5:"false";s:17:"print_form_enable";s:5:"false";s:12:"captcha_perm";s:5:"false";s:15:"honeypot_enable";s:5:"false";s:14:"redirect_query";s:5:"false";s:18:"redirect_email_off";s:5:"false";s:16:"silent_email_off";s:5:"false";s:16:"export_email_off";s:5:"false";s:19:"ex_fields_after_msg";s:5:"false";s:18:"email_inline_label";s:5:"false";s:19:"textarea_html_allow";s:5:"false";s:17:"enable_areyousure";s:5:"false";s:19:"auto_respond_enable";s:5:"false";s:17:"auto_respond_html";s:5:"false";s:13:"border_enable";s:5:"false";s:13:"aria_required";s:5:"false";s:12:"enable_reset";s:5:"false";s:18:"enable_credit_link";s:5:"false";s:23:"vcita_scheduling_button";s:5:"false";s:10:"vcita_link";s:5:"false";}', 'yes'),
(406, 'fs_contact_form3', 'a:167:{s:9:"form_name";s:8:"New Form";s:7:"welcome";s:41:"<p>Comments or questions are welcome.</p>";s:8:"email_to";s:29:"Webmaster,cristian@rotrer.com";s:9:"email_bcc";s:0:"";s:13:"email_subject";s:25:"Carolina Parsons Contact:";s:10:"email_from";s:0:"";s:14:"email_reply_to";s:0:"";s:6:"fields";a:4:{i:0;a:21:{s:8:"standard";s:1:"1";s:6:"delete";s:5:"false";s:5:"label";s:5:"Name:";s:4:"type";s:4:"text";s:4:"slug";s:9:"full_name";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:1;a:21:{s:8:"standard";s:1:"2";s:6:"delete";s:5:"false";s:5:"label";s:6:"Email:";s:4:"type";s:4:"text";s:4:"slug";s:5:"email";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:2;a:21:{s:8:"standard";s:1:"3";s:6:"delete";s:5:"false";s:5:"label";s:8:"Subject:";s:4:"type";s:4:"text";s:4:"slug";s:7:"subject";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}i:3;a:21:{s:8:"standard";s:1:"4";s:6:"delete";s:5:"false";s:5:"label";s:8:"Message:";s:4:"type";s:8:"textarea";s:4:"slug";s:7:"message";s:3:"req";s:4:"true";s:7:"default";s:0:"";s:7:"options";s:0:"";s:7:"max_len";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:6:"inline";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";}}s:11:"name_format";s:4:"name";s:16:"auto_fill_enable";s:4:"true";s:11:"date_format";s:10:"mm/dd/yyyy";s:13:"cal_start_day";s:1:"0";s:11:"time_format";s:2:"12";s:12:"attach_types";s:33:"doc,docx,pdf,txt,gif,jpg,jpeg,png";s:11:"attach_size";s:3:"1mb";s:12:"title_border";s:12:"Contact Form";s:14:"external_style";s:5:"false";s:10:"form_style";s:27:"width:99%; max-width:555px;";s:14:"left_box_style";s:39:"float:left; width:55%; max-width:270px;";s:15:"right_box_style";s:24:"float:left; width:235px;";s:11:"clear_style";s:11:"clear:both;";s:16:"field_left_style";s:70:"clear:left; float:left; width:99%; max-width:550px; margin-right:10px;";s:18:"field_follow_style";s:58:"float:left; padding-left:10px; width:99%; max-width:250px;";s:21:"field_prefollow_style";s:70:"clear:left; float:left; width:99%; max-width:250px; margin-right:10px;";s:11:"title_style";s:33:"text-align:left; padding-top:5px;";s:15:"field_div_style";s:16:"text-align:left;";s:20:"captcha_div_style_sm";s:42:"width:175px; height:50px; padding-top:2px;";s:19:"captcha_div_style_m";s:42:"width:250px; height:65px; padding-top:2px;";s:19:"captcha_image_style";s:72:"border-style:none; margin:0; padding:0px; padding-right:5px; float:left;";s:26:"captcha_reload_image_style";s:64:"border-style:none; margin:0; padding:0px; vertical-align:bottom;";s:16:"submit_div_style";s:46:"text-align:left; clear:both; padding-top:15px;";s:12:"border_style";s:65:"border:1px solid black; width:99%; max-width:550px; padding:10px;";s:14:"required_style";s:16:"text-align:left;";s:19:"required_text_style";s:16:"text-align:left;";s:10:"hint_style";s:38:"font-size:x-small; font-weight:normal;";s:11:"error_style";s:27:"text-align:left; color:red;";s:14:"redirect_style";s:16:"text-align:left;";s:14:"fieldset_style";s:65:"border:1px solid black; width:97%; max-width:500px; padding:10px;";s:11:"label_style";s:16:"text-align:left;";s:18:"option_label_style";s:15:"display:inline;";s:11:"field_style";s:54:"text-align:left; margin:0; width:99%; max-width:250px;";s:19:"captcha_input_style";s:38:"text-align:left; margin:0; width:50px;";s:14:"textarea_style";s:68:"text-align:left; margin:0; width:99%; max-width:250px; height:120px;";s:12:"select_style";s:16:"text-align:left;";s:14:"checkbox_style";s:11:"width:13px;";s:11:"radio_style";s:11:"width:13px;";s:17:"placeholder_style";s:27:"opacity:0.6; color:#333333;";s:12:"button_style";s:25:"cursor:pointer; margin:0;";s:11:"reset_style";s:25:"cursor:pointer; margin:0;";s:18:"vcita_button_style";s:156:"text-decoration:none; display:block; text-align:center; background:linear-gradient(to bottom, #ed6a31 0%, #e55627 100%); color:#fff !important; padding:8px;";s:22:"vcita_div_button_style";s:63:"border-left:1px dashed #ccc; margin-top:25px; padding:8px 20px;";s:16:"powered_by_style";s:74:"font-size:x-small; font-weight:normal; padding-top:5px; text-align:center;";s:22:"req_field_label_enable";s:4:"true";s:16:"tooltip_required";s:15:"Campo requerido";s:26:"req_field_indicator_enable";s:4:"true";s:19:"req_field_indicator";s:1:"*";s:10:"title_dept";s:0:"";s:12:"title_select";s:0:"";s:10:"title_name";s:6:"Nombre";s:11:"title_fname";s:8:"Apellido";s:11:"title_lname";s:0:"";s:11:"title_mname";s:0:"";s:12:"title_miname";s:0:"";s:11:"title_email";s:5:"Email";s:12:"title_email2";s:5:"Email";s:10:"title_subj";s:0:"";s:10:"title_mess";s:7:"Mensaje";s:10:"title_capt";s:0:"";s:12:"title_submit";s:0:"";s:16:"title_submitting";s:0:"";s:11:"title_reset";s:0:"";s:16:"title_areyousure";s:0:"";s:17:"text_message_sent";s:0:"";s:17:"text_print_button";s:0:"";s:15:"tooltip_captcha";s:0:"";s:15:"tooltip_refresh";s:16:"Refrescar imagen";s:17:"tooltip_filetypes";s:0:"";s:16:"tooltip_filesize";s:0:"";s:13:"error_correct";s:36:"Existe un error, intente nuevamente.";s:20:"error_contact_select";s:0:"";s:13:"error_subject";s:0:"";s:10:"error_name";s:0:"";s:11:"error_field";s:0:"";s:12:"error_select";s:0:"";s:11:"error_email";s:0:"";s:17:"error_email_check";s:0:"";s:12:"error_email2";s:0:"";s:9:"error_url";s:0:"";s:10:"error_date";s:0:"";s:10:"error_time";s:0:"";s:12:"error_maxlen";s:0:"";s:19:"error_captcha_blank";s:0:"";s:19:"error_captcha_wrong";s:0:"";s:13:"error_spambot";s:0:"";s:11:"error_input";s:0:"";s:14:"captcha_enable";s:4:"true";s:18:"captcha_perm_level";s:4:"read";s:19:"akismet_send_anyway";s:4:"true";s:14:"domain_protect";s:4:"true";s:20:"domain_protect_names";s:0:"";s:22:"auto_respond_from_name";s:16:"Carolina Parsons";s:23:"auto_respond_from_email";s:19:"cristian@rotrer.com";s:21:"auto_respond_reply_to";s:19:"cristian@rotrer.com";s:20:"auto_respond_subject";s:0:"";s:20:"auto_respond_message";s:0:"";s:15:"redirect_enable";s:4:"true";s:16:"redirect_seconds";i:3;s:12:"redirect_url";s:22:"http://dev.parsons.app";s:15:"redirect_ignore";s:0:"";s:15:"redirect_rename";s:0:"";s:12:"redirect_add";s:0:"";s:17:"submit_attributes";s:0:"";s:15:"form_attributes";s:0:"";s:13:"anchor_enable";s:4:"true";s:22:"enable_submit_oneclick";s:4:"true";s:15:"after_form_note";s:0:"";s:17:"success_page_html";s:0:"";s:17:"php_mailer_enable";s:9:"wordpress";s:18:"sender_info_enable";s:4:"true";s:11:"silent_send";s:3:"off";s:10:"silent_url";s:0:"";s:13:"silent_ignore";s:0:"";s:13:"silent_rename";s:0:"";s:10:"silent_add";s:0:"";s:24:"silent_conditional_field";s:0:"";s:24:"silent_conditional_value";s:0:"";s:13:"export_ignore";s:0:"";s:13:"export_rename";s:0:"";s:10:"export_add";s:0:"";s:14:"vcita_approved";s:5:"false";s:9:"vcita_uid";s:0:"";s:11:"vcita_email";s:0:"";s:15:"vcita_email_new";s:19:"cristian@rotrer.com";s:16:"vcita_first_name";s:0:"";s:15:"vcita_last_name";s:0:"";s:29:"vcita_scheduling_button_label";s:23:"Schedule an Appointment";s:26:"vcita_scheduling_link_text";s:68:"Click above to schedule an appointment using vCita Online Scheduling";s:19:"email_from_enforced";s:5:"false";s:21:"preserve_space_enable";s:5:"false";s:12:"double_email";s:5:"false";s:16:"name_case_enable";s:5:"false";s:15:"email_check_dns";s:5:"false";s:16:"email_check_easy";s:5:"false";s:10:"email_html";s:5:"false";s:15:"akismet_disable";s:5:"false";s:13:"captcha_small";s:5:"false";s:16:"email_hide_empty";s:5:"false";s:22:"email_keep_attachments";s:5:"false";s:17:"print_form_enable";s:5:"false";s:12:"captcha_perm";s:5:"false";s:15:"honeypot_enable";s:5:"false";s:14:"redirect_query";s:5:"false";s:18:"redirect_email_off";s:5:"false";s:16:"silent_email_off";s:5:"false";s:16:"export_email_off";s:5:"false";s:19:"ex_fields_after_msg";s:5:"false";s:18:"email_inline_label";s:5:"false";s:19:"textarea_html_allow";s:5:"false";s:17:"enable_areyousure";s:5:"false";s:19:"auto_respond_enable";s:5:"false";s:17:"auto_respond_html";s:5:"false";s:13:"border_enable";s:5:"false";s:13:"aria_required";s:5:"false";s:12:"enable_reset";s:5:"false";s:18:"enable_credit_link";s:5:"false";s:23:"vcita_scheduling_button";s:5:"false";s:10:"vcita_link";s:5:"false";}', 'yes'),
(421, 'CF7DBPlugin_NoSaveFields', '/.*wpcf7.*/,_wpnonce', 'yes'),
(422, 'CF7DBPlugin__version', '2.8.30', 'yes'),
(423, 'CF7DBPlugin__installed', '1', 'yes'),
(440, 'cpto_options', 'a:3:{s:8:"autosort";s:1:"1";s:9:"adminsort";s:0:"";s:10:"capability";s:13:"switch_themes";}', 'yes'),
(443, 'CPT_configured', 'TRUE', 'yes'),
(446, 'ct_content_types_version', '1.4.4', 'yes'),
(448, 'ct_content_types', 'a:1:{s:8:"archivos";a:24:{s:5:"label";s:8:"Archivos";s:14:"singular_label";s:7:"Archivo";s:5:"title";b:1;s:6:"editor";b:1;s:6:"author";b:0;s:9:"thumbnail";b:0;s:7:"excerpt";b:0;s:10:"trackbacks";b:0;s:13:"custom_fields";b:1;s:8:"comments";b:0;s:9:"revisions";b:0;s:26:"parent_child_relationships";b:0;s:15:"page_attributes";b:0;s:7:"created";i:1446775808;s:9:"createdby";s:5:"admin";s:7:"rewrite";b:1;s:7:"show_ui";b:1;s:6:"public";b:1;s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:13:"custom_fields";}s:10:"taxonomies";a:2:{i:0;s:8:"category";i:1;s:8:"post_tag";}s:11:"has_archive";b:1;s:17:"show_in_nav_menus";b:1;s:9:"menu_icon";s:13:"events-16.png";s:13:"menu_position";i:5;}}', 'yes'),
(449, 'ct_fields_types', 'a:1:{s:8:"archivos";a:1:{s:13:"admin_columns";a:3:{i:0;s:2:"cb";i:1;s:5:"title";i:2;s:6:"author";}}}', 'yes'),
(450, 'ct_categories_types', '', 'yes'),
(496, 'fs_contact_form2', 'a:171:{s:9:"form_name";s:8:"New Form";s:7:"welcome";s:41:"<p>Comments or questions are welcome.</p>";s:15:"after_form_note";s:0:"";s:8:"email_to";s:29:"Webmaster,cristian@rotrer.com";s:17:"php_mailer_enable";s:9:"wordpress";s:10:"email_from";s:0:"";s:19:"email_from_enforced";s:5:"false";s:14:"email_reply_to";s:0:"";s:9:"email_bcc";s:0:"";s:13:"email_subject";s:25:"Carolina Parsons Contact:";s:18:"email_subject_list";s:0:"";s:11:"name_format";s:4:"name";s:21:"preserve_space_enable";s:5:"false";s:12:"double_email";s:5:"false";s:16:"name_case_enable";s:5:"false";s:18:"sender_info_enable";s:4:"true";s:14:"domain_protect";s:4:"true";s:20:"domain_protect_names";s:0:"";s:13:"anchor_enable";s:4:"true";s:15:"email_check_dns";s:5:"false";s:16:"email_check_easy";s:5:"false";s:10:"email_html";s:5:"false";s:18:"email_inline_label";s:5:"false";s:16:"email_hide_empty";s:5:"false";s:17:"print_form_enable";s:5:"false";s:22:"email_keep_attachments";s:5:"false";s:15:"akismet_disable";s:5:"false";s:19:"akismet_send_anyway";s:4:"true";s:14:"captcha_enable";s:4:"true";s:13:"captcha_small";s:5:"false";s:12:"captcha_perm";s:5:"false";s:18:"captcha_perm_level";s:4:"read";s:15:"honeypot_enable";s:5:"false";s:15:"redirect_enable";s:4:"true";s:16:"redirect_seconds";i:3;s:12:"redirect_url";s:22:"http://dev.parsons.app";s:14:"redirect_query";s:5:"false";s:15:"redirect_ignore";s:0:"";s:15:"redirect_rename";s:0:"";s:12:"redirect_add";s:0:"";s:18:"redirect_email_off";s:5:"false";s:11:"silent_send";s:3:"off";s:10:"silent_url";s:0:"";s:13:"silent_ignore";s:0:"";s:13:"silent_rename";s:0:"";s:10:"silent_add";s:0:"";s:24:"silent_conditional_field";s:0:"";s:24:"silent_conditional_value";s:0:"";s:16:"silent_email_off";s:5:"false";s:13:"export_ignore";s:0:"";s:13:"export_rename";s:0:"";s:10:"export_add";s:0:"";s:16:"export_email_off";s:5:"false";s:11:"date_format";s:10:"mm/dd/yyyy";s:13:"cal_start_day";s:1:"0";s:11:"time_format";s:2:"12";s:12:"attach_types";s:33:"doc,docx,pdf,txt,gif,jpg,jpeg,png";s:11:"attach_size";s:3:"1mb";s:19:"textarea_html_allow";s:5:"false";s:17:"enable_areyousure";s:5:"false";s:22:"enable_submit_oneclick";s:4:"true";s:19:"auto_respond_enable";s:5:"false";s:17:"auto_respond_html";s:5:"false";s:22:"auto_respond_from_name";s:16:"Carolina Parsons";s:23:"auto_respond_from_email";s:19:"cristian@rotrer.com";s:21:"auto_respond_reply_to";s:19:"cristian@rotrer.com";s:20:"auto_respond_subject";s:0:"";s:20:"auto_respond_message";s:0:"";s:26:"req_field_indicator_enable";s:4:"true";s:22:"req_field_label_enable";s:4:"true";s:19:"req_field_indicator";s:1:"*";s:13:"border_enable";s:5:"false";s:14:"external_style";s:5:"false";s:13:"aria_required";s:5:"false";s:16:"auto_fill_enable";s:4:"true";s:15:"form_attributes";s:0:"";s:17:"submit_attributes";s:0:"";s:17:"success_page_html";s:0:"";s:12:"title_border";s:12:"Contact Form";s:10:"title_dept";s:0:"";s:12:"title_select";s:0:"";s:10:"title_name";s:0:"";s:11:"title_fname";s:0:"";s:11:"title_mname";s:0:"";s:12:"title_miname";s:0:"";s:11:"title_lname";s:0:"";s:11:"title_email";s:0:"";s:12:"title_email2";s:0:"";s:10:"title_subj";s:0:"";s:10:"title_mess";s:0:"";s:10:"title_capt";s:0:"";s:12:"title_submit";s:0:"";s:16:"title_submitting";s:0:"";s:11:"title_reset";s:0:"";s:16:"title_areyousure";s:0:"";s:17:"text_message_sent";s:0:"";s:17:"text_print_button";s:0:"";s:16:"tooltip_required";s:0:"";s:15:"tooltip_captcha";s:0:"";s:15:"tooltip_refresh";s:0:"";s:17:"tooltip_filetypes";s:0:"";s:16:"tooltip_filesize";s:0:"";s:12:"enable_reset";s:5:"false";s:18:"enable_credit_link";s:5:"false";s:20:"error_contact_select";s:0:"";s:10:"error_name";s:0:"";s:11:"error_email";s:0:"";s:17:"error_email_check";s:0:"";s:12:"error_email2";s:0:"";s:9:"error_url";s:0:"";s:10:"error_date";s:0:"";s:10:"error_time";s:0:"";s:12:"error_maxlen";s:0:"";s:11:"error_field";s:0:"";s:13:"error_subject";s:0:"";s:12:"error_select";s:0:"";s:11:"error_input";s:0:"";s:19:"error_captcha_blank";s:0:"";s:19:"error_captcha_wrong";s:0:"";s:13:"error_correct";s:0:"";s:13:"error_spambot";s:0:"";s:6:"fields";a:4:{i:0;a:20:{s:8:"standard";s:1:"1";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:5:"Name:";s:4:"slug";s:9:"full_name";s:4:"type";s:4:"text";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}i:1;a:20:{s:8:"standard";s:1:"2";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:6:"Email:";s:4:"slug";s:5:"email";s:4:"type";s:4:"text";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}i:2;a:20:{s:8:"standard";s:1:"3";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:8:"Subject:";s:4:"slug";s:7:"subject";s:4:"type";s:4:"text";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}i:3;a:20:{s:8:"standard";s:1:"4";s:7:"options";s:0:"";s:7:"default";s:0:"";s:6:"inline";s:5:"false";s:3:"req";s:4:"true";s:7:"disable";s:5:"false";s:6:"follow";s:5:"false";s:10:"hide_label";s:5:"false";s:11:"placeholder";s:5:"false";s:5:"label";s:8:"Message:";s:4:"slug";s:7:"message";s:4:"type";s:8:"textarea";s:7:"max_len";s:0:"";s:9:"label_css";s:0:"";s:9:"input_css";s:0:"";s:10:"attributes";s:0:"";s:5:"regex";s:0:"";s:11:"regex_error";s:0:"";s:5:"notes";s:0:"";s:11:"notes_after";s:0:"";}}s:23:"vcita_scheduling_button";s:5:"false";s:29:"vcita_scheduling_button_label";s:23:"Schedule an Appointment";s:14:"vcita_approved";s:5:"false";s:9:"vcita_uid";s:0:"";s:11:"vcita_email";s:0:"";s:15:"vcita_email_new";s:19:"cristian@rotrer.com";s:19:"vcita_confirm_token";s:0:"";s:20:"vcita_confirm_tokens";s:0:"";s:17:"vcita_initialized";s:5:"false";s:10:"vcita_link";s:5:"false";s:16:"vcita_first_name";s:0:"";s:15:"vcita_last_name";s:0:"";s:26:"vcita_scheduling_link_text";s:68:"Click above to schedule an appointment using vCita Online Scheduling";s:10:"form_style";s:27:"width:99%; max-width:555px;";s:14:"left_box_style";s:39:"float:left; width:55%; max-width:270px;";s:15:"right_box_style";s:24:"float:left; width:235px;";s:11:"clear_style";s:11:"clear:both;";s:16:"field_left_style";s:70:"clear:left; float:left; width:99%; max-width:550px; margin-right:10px;";s:21:"field_prefollow_style";s:70:"clear:left; float:left; width:99%; max-width:250px; margin-right:10px;";s:18:"field_follow_style";s:58:"float:left; padding-left:10px; width:99%; max-width:250px;";s:11:"title_style";s:33:"text-align:left; padding-top:5px;";s:15:"field_div_style";s:16:"text-align:left;";s:20:"captcha_div_style_sm";s:42:"width:175px; height:50px; padding-top:2px;";s:19:"captcha_div_style_m";s:42:"width:250px; height:65px; padding-top:2px;";s:19:"captcha_image_style";s:72:"border-style:none; margin:0; padding:0px; padding-right:5px; float:left;";s:26:"captcha_reload_image_style";s:64:"border-style:none; margin:0; padding:0px; vertical-align:bottom;";s:16:"submit_div_style";s:46:"text-align:left; clear:both; padding-top:15px;";s:12:"border_style";s:65:"border:1px solid black; width:99%; max-width:550px; padding:10px;";s:14:"required_style";s:16:"text-align:left;";s:19:"required_text_style";s:16:"text-align:left;";s:10:"hint_style";s:38:"font-size:x-small; font-weight:normal;";s:11:"error_style";s:27:"text-align:left; color:red;";s:14:"redirect_style";s:16:"text-align:left;";s:14:"fieldset_style";s:65:"border:1px solid black; width:97%; max-width:500px; padding:10px;";s:11:"label_style";s:16:"text-align:left;";s:18:"option_label_style";s:15:"display:inline;";s:11:"field_style";s:54:"text-align:left; margin:0; width:99%; max-width:250px;";s:19:"captcha_input_style";s:38:"text-align:left; margin:0; width:50px;";s:14:"textarea_style";s:68:"text-align:left; margin:0; width:99%; max-width:250px; height:120px;";s:12:"select_style";s:16:"text-align:left;";s:14:"checkbox_style";s:11:"width:13px;";s:11:"radio_style";s:11:"width:13px;";s:17:"placeholder_style";s:27:"opacity:0.6; color:#333333;";s:12:"button_style";s:25:"cursor:pointer; margin:0;";s:11:"reset_style";s:25:"cursor:pointer; margin:0;";s:18:"vcita_button_style";s:156:"text-decoration:none; display:block; text-align:center; background:linear-gradient(to bottom, #ed6a31 0%, #e55627 100%); color:#fff !important; padding:8px;";s:22:"vcita_div_button_style";s:63:"border-left:1px dashed #ccc; margin-top:25px; padding:8px 20px;";s:16:"powered_by_style";s:74:"font-size:x-small; font-weight:normal; padding-top:5px; text-align:center;";s:19:"ex_fields_after_msg";s:5:"false";}', 'yes'),
(744, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:19:"cristian@rotrer.com";s:7:"version";s:5:"4.1.8";s:9:"timestamp";i:1442373935;}', 'yes'),
(763, 'mashsb_settings', 'a:24:{s:19:"mashsharer_position";s:6:"manual";s:9:"frontpage";s:1:"1";s:11:"share_color";s:7:"#cccccc";s:13:"border_radius";s:7:"default";s:12:"button_width";s:3:"177";s:10:"mash_style";s:7:"default";s:18:"subscribe_behavior";s:7:"content";s:16:"visible_services";s:1:"2";s:8:"networks";a:3:{i:0;a:3:{s:2:"id";s:8:"facebook";s:6:"status";s:1:"1";s:4:"name";s:0:"";}i:1;a:3:{s:2:"id";s:7:"twitter";s:6:"status";s:1:"1";s:4:"name";s:0:"";}i:2;a:3:{s:2:"id";s:9:"subscribe";s:6:"status";s:1:"1";s:4:"name";s:0:"";}}s:16:"mashsharer_cache";s:3:"300";s:17:"mashsharer_apikey";s:0:"";s:28:"mashsharer_sharecount_domain";s:20:"free.sharedcount.com";s:18:"disable_sharecount";s:1:"1";s:15:"hide_sharecount";s:0:"";s:13:"excluded_from";s:0:"";s:15:"execution_order";s:4:"1000";s:10:"fake_count";s:0:"";s:19:"load_scripts_footer";s:1:"1";s:19:"facebook_count_mode";s:5:"total";s:13:"twitter_popup";s:1:"1";s:18:"mashsharer_hashtag";s:0:"";s:14:"subscribe_link";s:0:"";s:17:"subscribe_content";s:0:"";s:10:"custom_css";s:0:"";}', 'yes'),
(764, 'mashsb_version', '2.2.6', 'yes'),
(765, 'mashsb_installDate', '2015-02-23 01:29:48', 'yes'),
(766, 'mashsb_RatingDiv', 'no', 'yes'),
(767, 'mashsb_networks', 'a:3:{i:0;s:8:"Facebook";i:1;s:7:"Twitter";i:2;s:9:"Subscribe";}', 'yes'),
(782, 'ssb_version', '1.9', 'yes'),
(783, 'ssb_customer_type', 'free', 'yes'),
(790, 'ssb_social_sites', 'a:4:{s:2:"fb";s:2:"fb";s:7:"twitter";s:7:"twitter";s:5:"gplus";s:5:"gplus";s:5:"email";s:5:"email";}', 'yes'),
(791, 'ssb_share_archive_display', 'no', 'yes'),
(792, 'ssb_share_home_display', 'no', 'yes'),
(793, 'ssb_share_excerpt_display', 'no', 'yes'),
(845, 'ultimate-social-deux_options', 's:8408:"a:216:{s:12:"us_tweet_via";s:11:"caroparsons";s:18:"us_vkontakte_appid";s:0:"";s:17:"us_facebook_appid";s:15:"593203524047700";s:20:"us_total_shares_text";s:10:"Compartido";s:13:"us_open_graph";b:1;s:21:"us_bitly_access_token";s:0:"";s:19:"us_counts_transient";s:3:"600";s:10:"us_enqueue";s:9:"all_pages";s:24:"us_sticky_get_width_from";s:14:".entry-content";s:16:"us_sticky_offset";s:1:"0";s:26:"us_sticky_background_color";s:7:"#ffffff";s:18:"us_facebook_height";s:3:"500";s:17:"us_facebook_width";s:3:"900";s:17:"us_twitter_height";s:3:"500";s:16:"us_twitter_width";s:3:"900";s:20:"us_googleplus_height";s:3:"500";s:19:"us_googleplus_width";s:3:"900";s:19:"us_delicious_height";s:3:"550";s:18:"us_delicious_width";s:3:"550";s:17:"us_stumble_height";s:3:"550";s:16:"us_stumble_width";s:3:"550";s:18:"us_linkedin_height";s:3:"550";s:17:"us_linkedin_width";s:3:"550";s:19:"us_pinterest_height";s:3:"320";s:18:"us_pinterest_width";s:3:"720";s:16:"us_buffer_height";s:3:"500";s:15:"us_buffer_width";s:3:"900";s:16:"us_reddit_height";s:3:"500";s:15:"us_reddit_width";s:3:"900";s:19:"us_vkontakte_height";s:3:"500";s:18:"us_vkontakte_width";s:3:"900";s:23:"us_printfriendly_height";s:3:"500";s:22:"us_printfriendly_width";s:4:"1045";s:16:"us_pocket_height";s:3:"500";s:15:"us_pocket_width";s:3:"900";s:16:"us_tumblr_height";s:3:"500";s:15:"us_tumblr_width";s:3:"900";s:19:"us_flipboard_height";s:3:"500";s:18:"us_flipboard_width";s:3:"900";s:12:"us_ok_height";s:3:"500";s:11:"us_ok_width";s:3:"900";s:15:"us_weibo_height";s:3:"500";s:14:"us_weibo_width";s:3:"900";s:14:"us_xing_height";s:3:"500";s:13:"us_xing_width";s:3:"900";s:18:"us_managewp_height";s:3:"500";s:17:"us_managewp_width";s:3:"900";s:17:"us_meneame_height";s:3:"500";s:16:"us_meneame_width";s:3:"900";s:14:"us_digg_height";s:3:"500";s:13:"us_digg_width";s:3:"900";s:19:"us_floating_buttons";a:0:{}s:16:"us_floating_skin";s:7:"default";s:19:"us_floating_options";a:0:{}s:15:"us_floating_url";s:0:"";s:19:"us_floating_exclude";s:0:"";s:17:"us_floating_speed";s:4:"1000";s:20:"us_pages_top_buttons";a:0:{}s:20:"us_pages_top_options";a:0:{}s:17:"us_pages_top_skin";s:0:"";s:18:"us_pages_top_align";s:6:"center";s:20:"us_pages_top_exclude";s:0:"";s:23:"us_pages_top_share_text";s:0:"";s:23:"us_pages_top_margin_top";s:0:"";s:26:"us_pages_top_margin_bottom";s:0:"";s:23:"us_pages_bottom_buttons";a:0:{}s:20:"us_pages_bottom_skin";s:0:"";s:23:"us_pages_bottom_options";a:0:{}s:21:"us_pages_bottom_align";s:6:"center";s:23:"us_pages_bottom_exclude";s:0:"";s:26:"us_pages_bottom_share_text";s:0:"";s:26:"us_pages_bottom_margin_top";s:0:"";s:29:"us_pages_bottom_margin_bottom";s:0:"";s:23:"us_excerpts_top_buttons";a:0:{}s:20:"us_excerpts_top_skin";s:7:"default";s:23:"us_excerpts_top_options";a:0:{}s:21:"us_excerpts_top_align";s:6:"center";s:23:"us_excerpts_top_exclude";s:0:"";s:26:"us_excerpts_top_share_text";s:0:"";s:26:"us_excerpts_top_margin_top";s:0:"";s:29:"us_excerpts_top_margin_bottom";s:0:"";s:18:"us_excerpts_bottom";a:0:{}s:23:"us_excerpts_bottom_skin";s:7:"minimal";s:26:"us_excerpts_bottom_options";a:0:{}s:24:"us_excerpts_bottom_align";s:4:"left";s:26:"us_excerpts_bottom_exclude";s:0:"";s:29:"us_excerpts_bottom_share_text";s:0:"";s:29:"us_excerpts_bottom_margin_top";s:0:"";s:32:"us_excerpts_bottom_margin_bottom";s:0:"";s:20:"us_posts_top_buttons";a:0:{}s:17:"us_posts_top_skin";s:7:"default";s:20:"us_posts_top_options";a:0:{}s:18:"us_posts_top_align";s:5:"right";s:20:"us_posts_top_exclude";s:0:"";s:23:"us_posts_top_share_text";s:0:"";s:23:"us_posts_top_margin_top";s:0:"";s:26:"us_posts_top_margin_bottom";s:0:"";s:23:"us_posts_bottom_buttons";a:0:{}s:20:"us_posts_bottom_skin";s:7:"minimal";s:23:"us_posts_bottom_options";a:0:{}s:21:"us_posts_bottom_align";s:5:"right";s:23:"us_posts_bottom_exclude";s:0:"";s:26:"us_posts_bottom_share_text";s:0:"";s:26:"us_posts_bottom_margin_top";s:0:"";s:29:"us_posts_bottom_margin_bottom";s:0:"";s:14:"us_cpt_top_cpt";s:0:"";s:18:"us_cpt_top_buttons";a:0:{}s:15:"us_cpt_top_skin";s:0:"";s:18:"us_cpt_top_options";a:0:{}s:16:"us_cpt_top_align";s:6:"center";s:18:"us_cpt_top_exclude";s:0:"";s:21:"us_cpt_top_share_text";s:0:"";s:21:"us_cpt_top_margin_top";s:0:"";s:24:"us_cpt_top_margin_bottom";s:0:"";s:17:"us_cpt_bottom_cpt";s:0:"";s:21:"us_cpt_bottom_buttons";a:0:{}s:18:"us_cpt_bottom_skin";s:0:"";s:21:"us_cpt_bottom_options";a:0:{}s:19:"us_cpt_bottom_align";s:6:"center";s:21:"us_cpt_bottom_exclude";s:0:"";s:24:"us_cpt_bottom_share_text";s:0:"";s:24:"us_cpt_bottom_margin_top";s:0:"";s:27:"us_cpt_bottom_margin_bottom";s:0:"";s:14:"us_hover_color";s:7:"#000000";s:17:"us_facebook_color";s:7:"#000000";s:16:"us_twitter_color";s:7:"#000000";s:19:"us_googleplus_color";s:7:"#000000";s:18:"us_pinterest_color";s:7:"#000000";s:17:"us_linkedin_color";s:7:"#000000";s:18:"us_delicious_color";s:7:"#000000";s:16:"us_stumble_color";s:7:"#E94B24";s:15:"us_buffer_color";s:7:"#000000";s:15:"us_reddit_color";s:7:"#CEE3F8";s:18:"us_vkontakte_color";s:7:"#537599";s:13:"us_mail_color";s:7:"#666666";s:13:"us_love_color";s:7:"#FF0000";s:15:"us_pocket_color";s:7:"#ee4056";s:14:"us_print_color";s:7:"#60d0d4";s:18:"us_flipboard_color";s:7:"#c10000";s:11:"us_ok_color";s:7:"#f2720c";s:14:"us_weibo_color";s:7:"#e64141";s:17:"us_managewp_color";s:7:"#098ae0";s:13:"us_xing_color";s:7:"#026466";s:17:"us_whatsapp_color";s:7:"#34af23";s:16:"us_meneame_color";s:7:"#ff6400";s:13:"us_digg_color";s:7:"#000000";s:17:"us_comments_color";s:7:"#b69823";s:13:"us_more_color";s:7:"#53B27C";s:15:"us_tumblr_color";s:7:"#529ecc";s:15:"us_feedly_color";s:7:"#414141";s:16:"us_youtube_color";s:7:"#cc181e";s:14:"us_vimeo_color";s:7:"#1bb6ec";s:17:"us_dribbble_color";s:7:"#f72b7f";s:15:"us_envato_color";s:7:"#82b540";s:15:"us_github_color";s:7:"#201e1f";s:19:"us_soundcloud_color";s:7:"#ff6f00";s:16:"us_behance_color";s:7:"#1769ff";s:18:"us_instagram_color";s:7:"#48769c";s:18:"us_feedpress_color";s:7:"#ffafaf";s:18:"us_mailchimp_color";s:7:"#6dc5dc";s:15:"us_flickr_color";s:7:"#0062dd";s:16:"us_members_color";s:7:"#0ab071";s:14:"us_posts_color";s:7:"#924e2a";s:33:"us_border_radius_sharing_top_left";s:1:"0";s:34:"us_border_radius_sharing_top_right";s:1:"0";s:36:"us_border_radius_sharing_bottom_left";s:1:"0";s:37:"us_border_radius_sharing_bottom_right";s:1:"0";s:35:"us_border_radius_fan_count_top_left";s:1:"0";s:36:"us_border_radius_fan_count_top_right";s:1:"0";s:38:"us_border_radius_fan_count_bottom_left";s:1:"0";s:39:"us_border_radius_fan_count_bottom_right";s:1:"0";s:13:"us_custom_css";s:12:"float:right;";s:14:"us_mail_header";s:23:"Share with your friends";s:18:"us_mail_from_email";s:19:"cristian@rotrer.com";s:17:"us_mail_from_name";s:16:"Carolina Parsons";s:15:"us_mail_subject";s:55:"A visitor of {site_title} shared {post_title} with you.";s:12:"us_mail_body";s:154:"I read this article and found it very interesting, thought it might be something for you. The article is called {post_title} and is located at {post_url}.";s:18:"us_mail_bcc_enable";s:2:"no";s:22:"us_mail_captcha_enable";s:3:"yes";s:24:"us_mail_captcha_question";s:27:"What is the sum of 7 and 2?";s:22:"us_mail_captcha_answer";s:1:"9";s:11:"us_mail_try";s:23:"Trying to send email...";s:15:"us_mail_success";s:34:"Great work! Your message was sent.";s:8:"us_cache";s:1:"2";s:14:"us_facebook_id";s:22:"CarolinaParsonsOficial";s:13:"us_twitter_id";s:11:"caroparsons";s:14:"us_twitter_key";s:25:"scSouxVkIaXKf6AEdkKt9E2xK";s:17:"us_twitter_secret";s:50:"8y6Qet4q5A06dwPJLQB0B4C6z3z7HSQ3FlwZNTSm21GZZWgJmH";s:12:"us_google_id";s:7:"leonrov";s:13:"us_google_key";s:39:"AIzaSyD8XJfk_eVk4it-oFpB7tkm7z7J1IrbTCQ";s:14:"us_linkedin_id";s:0:"";s:15:"us_linkedin_app";s:0:"";s:15:"us_linkedin_api";s:0:"";s:13:"us_youtube_id";s:0:"";s:11:"us_vimeo_id";s:0:"";s:13:"us_behance_id";s:0:"";s:14:"us_behance_api";s:0:"";s:16:"us_soundcloud_id";s:0:"";s:22:"us_soundcloud_username";s:0:"";s:14:"us_dribbble_id";s:0:"";s:12:"us_github_id";s:0:"";s:12:"us_envato_id";s:0:"";s:15:"us_delicious_id";s:0:"";s:16:"us_instagram_api";s:0:"";s:21:"us_instagram_username";s:0:"";s:15:"us_vkontakte_id";s:0:"";s:21:"us_pinterest_username";s:0:"";s:12:"us_flickr_id";s:0:"";s:13:"us_flickr_api";s:0:"";s:17:"us_mailchimp_name";s:0:"";s:16:"us_mailchimp_api";s:0:"";s:17:"us_mailchimp_link";s:0:"";s:16:"us_feedpress_url";s:0:"";s:19:"us_feedpress_manual";s:0:"";s:10:"us_license";s:36:"de1e418c-1a2e-4675-8b54-d20bee20e79f";s:15:"us_license_help";s:0:"";}";', 'yes'),
(889, 'wpmdb_error_log', '********************************************\n******  Log date: 2015/02/12 17:02:01 ******\n********************************************\n\nWPMDB Error: The connection to the remote server has timed out, no changes have been committed. (#134 - scope: ajax_verify_connection_to_remote_site)\n\nAttempted to connect to: http://dev.parsons.app/wp/wp-admin/admin-ajax.php\n\nWP_Error Object\n(\n    [errors:WP_Error:private] => Array\n        (\n            [http_request_failed] => Array\n                (\n                    [0] => Operation timed out after 10001 milliseconds with 0 bytes received\n                )\n\n        )\n\n    [error_data:WP_Error:private] => Array\n        (\n        )\n\n)\n\n\n', 'yes'),
(890, 'wpmdb_settings', 'a:7:{s:11:"max_request";i:1048576;s:3:"key";s:32:"eiRRJgsajbSld2yfbuMqnRh5Jd/5/c/d";s:10:"allow_pull";b:1;s:10:"allow_push";b:1;s:8:"profiles";a:2:{i:0;a:17:{s:13:"save_computer";s:1:"1";s:9:"gzip_file";s:1:"1";s:13:"replace_guids";s:1:"1";s:12:"exclude_spam";s:1:"0";s:19:"keep_active_plugins";s:1:"0";s:13:"create_backup";s:1:"0";s:6:"action";s:8:"savefile";s:15:"connection_info";s:0:"";s:11:"replace_old";a:2:{i:1;s:17:"//dev.parsons.app";i:2;s:22:"/Volumes/HDD2/Sites/cp";}s:11:"replace_new";a:2:{i:1;s:17:"//dev.parsons.app";i:2;s:22:"/Volumes/HDD2/Sites/cp";}s:20:"table_migrate_option";s:24:"migrate_only_with_prefix";s:24:"post_type_migrate_option";s:22:"migrate_all_post_types";s:13:"backup_option";s:23:"backup_only_with_prefix";s:22:"save_migration_profile";s:1:"1";s:29:"save_migration_profile_option";s:1:"0";s:18:"create_new_profile";s:0:"";s:4:"name";s:3:"leo";}i:1;a:17:{s:13:"save_computer";s:1:"1";s:9:"gzip_file";s:1:"1";s:13:"replace_guids";s:1:"1";s:12:"exclude_spam";s:1:"0";s:19:"keep_active_plugins";s:1:"0";s:13:"create_backup";s:1:"0";s:6:"action";s:8:"savefile";s:15:"connection_info";s:0:"";s:11:"replace_old";a:2:{i:1;s:17:"//dev.parsons.app";i:2;s:22:"/Volumes/HDD2/Sites/cp";}s:11:"replace_new";a:2:{i:1;s:17:"//dev.parsons.app";i:2;s:22:"/Volumes/HDD2/Sites/cp";}s:20:"table_migrate_option";s:24:"migrate_only_with_prefix";s:24:"post_type_migrate_option";s:22:"migrate_all_post_types";s:13:"backup_option";s:23:"backup_only_with_prefix";s:22:"save_migration_profile";s:1:"1";s:29:"save_migration_profile_option";s:1:"1";s:18:"create_new_profile";s:0:"";s:4:"name";s:8:"cristian";}}s:7:"licence";s:0:"";s:10:"verify_ssl";b:0;}', 'yes'),
(1199, 'db_upgraded', '', 'yes'),
(3262, 'can_compress_scripts', '1', 'yes'),
(3716, 'ht_gallery_category_children', 'a:1:{i:45;a:1:{i:0;i:46;}}', 'yes'),
(3732, 'category_children', 'a:3:{i:2;a:5:{i:0;i:3;i:1;i:4;i:2;i:5;i:3;i:6;i:4;i:43;}i:36;a:4:{i:0;i:37;i:1;i:39;i:2;i:42;i:3;i:47;}i:39;a:1:{i:0;i:44;}}', 'yes') ;

#
# End of data contents of table `cp_options`
# --------------------------------------------------------



#
# Delete any existing table `cp_postmeta`
#

DROP TABLE IF EXISTS `cp_postmeta`;


#
# Table structure of table `cp_postmeta`
#

CREATE TABLE `cp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=1545 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_postmeta`
#
INSERT INTO `cp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1453223352:1'),
(21, 16, '_edit_last', '1'),
(22, 16, '_edit_lock', '1423828515:1'),
(33, 21, '_edit_lock', '1446775343:1'),
(37, 21, '_edit_last', '1'),
(39, 21, '_wp_old_slug', 'sed-diam-nonummy-nibh-euismod-tincidunt-aut-laoreet-dolore-magna-aliquam'),
(40, 24, '_edit_lock', '1423711201:1'),
(44, 24, '_edit_last', '1'),
(46, 24, '_wp_old_slug', 'sed-diam-nonummy-nibh-euismod-tincidunt-aut-laoreet-dolore-magna-aliquam-2'),
(76, 30, '_menu_item_type', 'taxonomy'),
(77, 30, '_menu_item_menu_item_parent', '0'),
(78, 30, '_menu_item_object_id', '2'),
(79, 30, '_menu_item_object', 'category'),
(80, 30, '_menu_item_target', ''),
(81, 30, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(82, 30, '_menu_item_xfn', ''),
(83, 30, '_menu_item_url', ''),
(94, 38, '_edit_last', '1'),
(95, 38, '_edit_lock', '1446773971:1'),
(96, 38, '_wp_page_template', 'templates/page-carrera.php'),
(97, 40, '_edit_last', '1'),
(98, 40, '_edit_lock', '1453169836:1'),
(99, 40, '_wp_page_template', 'templates/page-contacto.php'),
(100, 42, '_menu_item_type', 'post_type'),
(101, 42, '_menu_item_menu_item_parent', '0'),
(102, 42, '_menu_item_object_id', '40'),
(103, 42, '_menu_item_object', 'page'),
(104, 42, '_menu_item_target', ''),
(105, 42, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(106, 42, '_menu_item_xfn', ''),
(107, 42, '_menu_item_url', ''),
(145, 50, '_edit_last', '1'),
(146, 50, '_edit_lock', '1446776211:1'),
(1164, 318, '_wp_attached_file', '2015/02/693x693px.jpg'),
(1165, 318, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:693;s:6:"height";i:693;s:4:"file";s:21:"2015/02/693x693px.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"693x693px-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"693x693px-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:13:"ept_thumbnail";a:4:{s:4:"file";s:19:"693x693px-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:21:"693x693px-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:21:"693x693px-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}s:13:"galeria-small";a:4:{s:4:"file";s:21:"693x693px-226x226.jpg";s:5:"width";i:226;s:6:"height";i:226;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1166, 21, '_thumbnail_id', '318'),
(1168, 319, '_edit_last', '1'),
(1169, 319, '_edit_lock', '1454179318:1'),
(1170, 319, '_thumbnail_id', '318'),
(1172, 16, '_thumbnail_id', '318'),
(1176, 321, '_edit_last', '1'),
(1177, 321, '_edit_lock', '1424886011:1'),
(1198, 340, '_menu_item_type', 'taxonomy'),
(1199, 340, '_menu_item_menu_item_parent', '0'),
(1200, 340, '_menu_item_object_id', '36'),
(1201, 340, '_menu_item_object', 'category'),
(1202, 340, '_menu_item_target', ''),
(1203, 340, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1204, 340, '_menu_item_xfn', ''),
(1205, 340, '_menu_item_url', ''),
(1373, 321, '_wp_trash_meta_status', 'publish'),
(1374, 321, '_wp_trash_meta_time', '1453224173'),
(1398, 371, '_edit_last', '1'),
(1399, 371, '_edit_lock', '1453232399:1'),
(1404, 371, '_wp_trash_meta_status', 'publish'),
(1405, 371, '_wp_trash_meta_time', '1454186944'),
(1406, 319, '_wp_trash_meta_status', 'publish'),
(1407, 319, '_wp_trash_meta_time', '1454186944'),
(1408, 24, '_wp_trash_meta_status', 'publish'),
(1409, 24, '_wp_trash_meta_time', '1454186944'),
(1410, 24, '_wp_trash_meta_comments_status', 'a:3:{i:2;s:1:"0";i:3;s:1:"0";i:4;s:1:"0";}'),
(1411, 21, '_wp_trash_meta_status', 'publish'),
(1412, 21, '_wp_trash_meta_time', '1454186944'),
(1413, 16, '_wp_trash_meta_status', 'publish'),
(1414, 16, '_wp_trash_meta_time', '1454186944'),
(1427, 387, '_wp_attached_file', '2016/01/portada_revista_antilope_fotografo_simon_pais_carolina_parsons.jpg'),
(1428, 387, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:2248;s:4:"file";s:74:"2016/01/portada_revista_antilope_fotografo_simon_pais_carolina_parsons.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:72:"portada_revista_antilope_fotografo_simon_pais_carolina_parsons-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:74:"portada_revista_antilope_fotografo_simon_pais_carolina_parsons-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:73:"portada_revista_antilope_fotografo_simon_pais_carolina_parsons-71x100.jpg";s:5:"width";i:71;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1429, 388, '_wp_attached_file', '2016/01/revista_antilope_entrevista_blood_sugar_baby_carolina_parsons.jpg'),
(1430, 388, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1138;s:4:"file";s:73:"2016/01/revista_antilope_entrevista_blood_sugar_baby_carolina_parsons.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:71:"revista_antilope_entrevista_blood_sugar_baby_carolina_parsons-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:73:"revista_antilope_entrevista_blood_sugar_baby_carolina_parsons-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:73:"revista_antilope_entrevista_blood_sugar_baby_carolina_parsons-141x100.jpg";s:5:"width";i:141;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1431, 389, '_wp_attached_file', '2016/01/revista_antilope_entrevista_carolina_parsons.jpg'),
(1432, 389, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:2248;s:4:"file";s:56:"2016/01/revista_antilope_entrevista_carolina_parsons.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:54:"revista_antilope_entrevista_carolina_parsons-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:56:"revista_antilope_entrevista_carolina_parsons-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:55:"revista_antilope_entrevista_carolina_parsons-71x100.jpg";s:5:"width";i:71;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1433, 390, '_wp_attached_file', '2016/01/revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons.jpg'),
(1434, 390, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1124;s:4:"file";s:77:"2016/01/revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:75:"revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:77:"revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:77:"revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons-142x100.jpg";s:5:"width";i:142;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1435, 391, '_wp_attached_file', '2016/01/revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2.jpg'),
(1436, 391, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:843;s:6:"height";i:1280;s:4:"file";s:78:"2016/01/revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:76:"revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:78:"revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:77:"revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2-66x100.jpg";s:5:"width";i:66;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:1;}}'),
(1437, 386, '_edit_last', '1'),
(1438, 386, '_edit_lock', '1454188092:1'),
(1439, 386, '_ht_gallery_images', '387,388,389,390,391'),
(1440, 386, '_ht_gallery_starred_image', ''),
(1441, 388, '_edit_lock', '1454187512:1'),
(1442, 393, '_edit_last', '1'),
(1443, 393, '_edit_lock', '1454187739:1'),
(1444, 393, '_wp_page_template', 'default'),
(1445, 395, '_menu_item_type', 'ht_gallery_post'),
(1446, 395, '_menu_item_menu_item_parent', '0'),
(1447, 395, '_menu_item_object_id', '0'),
(1448, 395, '_menu_item_object', 'ht_gallery_post'),
(1449, 395, '_menu_item_target', ''),
(1450, 395, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1451, 395, '_menu_item_xfn', ''),
(1452, 395, '_menu_item_url', ''),
(1453, 395, '_menu_item_orphaned', '1454187886'),
(1463, 397, '_menu_item_type', 'ht_gallery_post'),
(1464, 397, '_menu_item_menu_item_parent', '0'),
(1465, 397, '_menu_item_object_id', '0'),
(1466, 397, '_menu_item_object', 'ht_gallery_post'),
(1467, 397, '_menu_item_target', ''),
(1468, 397, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1469, 397, '_menu_item_xfn', '') ;
INSERT INTO `cp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1470, 397, '_menu_item_url', ''),
(1471, 397, '_menu_item_orphaned', '1454187902'),
(1478, 399, '_edit_last', '1'),
(1479, 399, '_edit_lock', '1454191317:1'),
(1480, 400, '_wp_attached_file', 'blog_danilo_brasil_1_carolina_parsons.jpg'),
(1481, 400, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1230;s:4:"file";s:41:"blog_danilo_brasil_1_carolina_parsons.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:47:"blog_danilo_brasil_1_carolina_parsons-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:49:"blog_danilo_brasil_1_carolina_parsons-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:49:"blog_danilo_brasil_1_carolina_parsons-130x100.jpg";s:5:"width";i:130;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1482, 399, 'foto_grande_galeria', '400'),
(1483, 399, '_foto_grande_galeria', 'field_54d90170737e1'),
(1484, 399, 'foto_pequena_galeria', '405'),
(1485, 399, '_foto_pequena_galeria', 'field_54d915af295b8'),
(1486, 401, '_edit_last', '1'),
(1487, 401, '_edit_lock', '1454189928:1'),
(1488, 402, '_wp_attached_file', '575.jpg'),
(1489, 402, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:575;s:6:"height";i:575;s:4:"file";s:7:"575.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:13:"575-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:15:"575-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:15:"575-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1490, 401, '_thumbnail_id', '402'),
(1492, 404, '_edit_last', '1'),
(1493, 404, '_edit_lock', '1454191560:1'),
(1494, 405, '_wp_attached_file', 'editorial.jpg'),
(1495, 405, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:13:"editorial.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:19:"editorial-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:21:"editorial-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:21:"editorial-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1496, 406, '_wp_attached_file', 'portadas.jpg'),
(1497, 406, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:12:"portadas.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:18:"portadas-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:20:"portadas-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:20:"portadas-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1498, 407, '_wp_attached_file', 'prensa.jpg'),
(1499, 407, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:10:"prensa.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:16:"prensa-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:18:"prensa-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:18:"prensa-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1500, 408, '_wp_attached_file', 'publicidad.jpg'),
(1501, 408, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:14:"publicidad.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:20:"publicidad-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:22:"publicidad-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:22:"publicidad-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1502, 409, '_wp_attached_file', 'recortes.jpg'),
(1503, 409, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:12:"recortes.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:18:"recortes-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:20:"recortes-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:20:"recortes-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1504, 404, 'foto_grande_galeria', '409'),
(1505, 404, '_foto_grande_galeria', 'field_54d90170737e1'),
(1506, 404, 'foto_pequena_galeria', '409'),
(1507, 404, '_foto_pequena_galeria', 'field_54d915af295b8'),
(1512, 411, '_edit_last', '1'),
(1513, 411, '_edit_lock', '1454191241:1'),
(1514, 411, 'foto_grande_galeria', '387'),
(1515, 411, '_foto_grande_galeria', 'field_54d90170737e1'),
(1516, 411, 'foto_pequena_galeria', '406'),
(1517, 411, '_foto_pequena_galeria', 'field_54d915af295b8'),
(1518, 412, '_edit_last', '1'),
(1519, 412, '_edit_lock', '1454191566:1'),
(1520, 412, 'foto_grande_galeria', '407'),
(1521, 412, '_foto_grande_galeria', 'field_54d90170737e1'),
(1522, 412, 'foto_pequena_galeria', '407'),
(1523, 412, '_foto_pequena_galeria', 'field_54d915af295b8'),
(1524, 413, '_edit_last', '1'),
(1525, 413, '_edit_lock', '1454191549:1'),
(1526, 413, 'foto_grande_galeria', '408'),
(1527, 413, '_foto_grande_galeria', 'field_54d90170737e1'),
(1528, 413, 'foto_pequena_galeria', '408'),
(1529, 413, '_foto_pequena_galeria', 'field_54d915af295b8'),
(1530, 413, '_wp_trash_meta_status', 'publish'),
(1531, 413, '_wp_trash_meta_time', '1454191730'),
(1532, 416, '_edit_last', '1'),
(1533, 416, '_edit_lock', '1454195706:1'),
(1534, 417, '_wp_attached_file', 'publicidad1.jpg'),
(1535, 417, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:480;s:6:"height";i:480;s:4:"file";s:15:"publicidad1.jpg";s:5:"sizes";a:3:{s:13:"ept_thumbnail";a:4:{s:4:"file";s:21:"publicidad1-80x80.jpg";s:5:"width";i:80;s:6:"height";i:80;s:9:"mime-type";s:10:"image/jpeg";}s:10:"ept_medium";a:4:{s:4:"file";s:23:"publicidad1-320x240.jpg";s:5:"width";i:320;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";}s:27:"wp-image-form-field-preview";a:4:{s:4:"file";s:23:"publicidad1-100x100.jpg";s:5:"width";i:100;s:6:"height";i:100;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:11:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";s:11:"orientation";i:0;}}'),
(1536, 416, 'foto_grande_galeria', '417'),
(1537, 416, '_foto_grande_galeria', 'field_54d90170737e1'),
(1538, 416, 'foto_pequena_galeria', '417'),
(1539, 416, '_foto_pequena_galeria', 'field_54d915af295b8'),
(1540, 418, '_edit_lock', '1454195969:1'),
(1541, 418, '_edit_last', '1'),
(1542, 418, '_thumbnail_id', '409'),
(1544, 418, '_wp_old_slug', 'hola-mundo') ;

#
# End of data contents of table `cp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `cp_posts`
#

DROP TABLE IF EXISTS `cp_posts`;


#
# Table structure of table `cp_posts`
#

CREATE TABLE `cp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(20) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=420 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_posts`
#
INSERT INTO `cp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(4, 1, '2015-02-05 20:18:15', '2015-02-05 20:18:15', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:12:"options_page";s:8:"operator";s:2:"==";s:5:"value";s:22:"theme-general-settings";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";}', 'Home Slider', 'home-slider', 'publish', 'closed', 'closed', '', 'group_54d3cee943294', '', '', '2016-01-19 14:09:09', '2016-01-19 17:09:09', '', 0, 'http://dev.parsons.app/?post_type=acf-field-group&#038;p=4', 0, 'acf-field-group', '', 0),
(5, 1, '2015-02-05 20:18:15', '2015-02-05 20:18:15', 'a:9:{s:4:"type";s:8:"repeater";s:12:"instructions";s:16:"Fotos destacadas";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:3:"min";s:0:"";s:3:"max";s:0:"";s:6:"layout";s:5:"table";s:12:"button_label";s:7:"Add Row";}', 'Fotos Slider Home', 'fotos_slider_home', 'publish', 'open', 'open', '', 'field_54d3cf560dd40', '', '', '2015-02-06 12:38:04', '2015-02-06 12:38:04', '', 4, 'http://dev.parsons.app/?post_type=acf-field&#038;p=5', 0, 'acf-field', '', 0),
(6, 1, '2015-02-05 20:18:15', '2015-02-05 20:18:15', 'a:8:{s:4:"type";s:5:"image";s:12:"instructions";s:23:"Formatos jpg, png, gif.";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";}', 'Foto', 'foto_slider_h', 'publish', 'open', 'open', '', 'field_54d3cfb70dd41', '', '', '2015-02-06 12:38:04', '2015-02-06 12:38:04', '', 5, 'http://dev.parsons.app/?post_type=acf-field&#038;p=6', 0, 'acf-field', '', 0),
(7, 1, '2015-02-05 20:18:15', '2015-02-05 20:18:15', 'a:12:{s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";s:9:"maxlength";s:0:"";s:8:"readonly";i:0;s:8:"disabled";i:0;}', '', '', 'publish', 'open', 'open', '', 'field_54d3d0000dd42', '', '', '2015-02-05 20:18:15', '2015-02-05 20:18:15', '', 5, 'http://dev.parsons.app/?post_type=acf-field&p=7', 1, 'acf-field', '', 0),
(16, 1, '2015-02-06 12:57:43', '2015-02-06 12:57:43', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', 'Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna aliquam', '', 'trash', 'open', 'open', '', 'sed-diam-nonummy-nibh-euismod-tincidunt-aut-laoreet-dolore-magna-aliquam', '', '', '2016-01-30 17:49:04', '2016-01-30 20:49:04', '', 0, 'http://dev.parsons.app/?p=16', 0, 'post', '', 0),
(17, 1, '2015-02-06 12:57:43', '2015-02-06 12:57:43', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', 'Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna aliquam', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2015-02-06 12:57:43', '2015-02-06 12:57:43', '', 16, 'http://dev.parsons.app/?p=17', 0, 'revision', '', 0),
(19, 1, '2015-02-06 10:01:27', '2015-02-06 13:01:27', '<a href="http://dev.parsons.app/wp-content/uploads/2015/02/conten1.jpg"><img class="alignnone size-medium wp-image-18" src="http://dev.parsons.app/wp-content/uploads/2015/02/conten1-300x250.jpg" alt="conten1" width="300" height="250" /></a>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', 'Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna aliquam', '', 'inherit', 'open', 'open', '', '16-revision-v1', '', '', '2015-02-06 10:01:27', '2015-02-06 13:01:27', '', 16, 'http://dev.parsons.app/?p=19', 0, 'revision', '', 0),
(21, 1, '2015-02-06 13:53:07', '2015-02-06 16:53:07', '2 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '2 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'trash', 'open', 'open', '', 'sed-diam-nonummy-nibh-euismod-tincidunt-aut-laoreet-dolore-magna-aliquam-2', '', '', '2016-01-30 17:49:04', '2016-01-30 20:49:04', '', 0, 'http://dev.parsons.app/?p=21', 0, 'post', '', 0),
(23, 1, '2015-02-06 13:53:07', '2015-02-06 16:53:07', '2 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '2 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'inherit', 'open', 'open', '', '21-revision-v1', '', '', '2015-02-06 13:53:07', '2015-02-06 16:53:07', '', 21, 'http://dev.parsons.app/?p=23', 0, 'revision', '', 0),
(24, 1, '2015-02-06 13:55:27', '2015-02-06 16:55:27', '3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '3 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'trash', 'open', 'open', '', 'sed-diam-nonummy-nibh-euismod-tincidunt-aut-laoreet-dolore-magna-aliquam-2-2', '', '', '2016-01-30 17:49:04', '2016-01-30 20:49:04', '', 0, 'http://dev.parsons.app/?p=24', 0, 'post', '', 2),
(26, 1, '2015-02-06 13:55:27', '2015-02-06 16:55:27', '3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '3 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2015-02-06 13:55:27', '2015-02-06 16:55:27', '', 24, 'http://dev.parsons.app/?p=26', 0, 'revision', '', 0),
(30, 1, '2015-02-06 16:03:39', '2015-02-06 19:03:39', ' ', '', '', 'publish', 'open', 'open', '', '30', '', '', '2016-01-30 20:50:35', '2016-01-30 23:50:35', '', 0, 'http://dev.parsons.app/?p=30', 1, 'nav_menu_item', '', 0),
(38, 1, '2015-02-06 16:08:42', '2015-02-06 19:08:42', 'Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas "Letraset", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.\r\n\r\nLorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas "Letraset", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.\r\n\r\n[gallery link="none" ids="298,300,299,297,296,295"]', 'Carrera', '', 'publish', 'open', 'open', '', 'bio', '', '', '2015-11-05 22:37:32', '2015-11-06 01:37:32', '', 0, 'http://dev.parsons.app/?page_id=38', 0, 'page', '', 0),
(39, 1, '2015-02-06 16:08:42', '2015-02-06 19:08:42', '', 'Bio', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2015-02-06 16:08:42', '2015-02-06 19:08:42', '', 38, 'http://dev.parsons.app/?p=39', 0, 'revision', '', 0),
(40, 1, '2015-02-06 16:08:53', '2015-02-06 19:08:53', '[si-contact-form form=\'3\']', 'Contacto', '', 'publish', 'open', 'open', '', 'contacto', '', '', '2015-02-10 13:07:29', '2015-02-10 16:07:29', '', 0, 'http://dev.parsons.app/?page_id=40', 0, 'page', '', 0),
(41, 1, '2015-02-06 16:08:53', '2015-02-06 19:08:53', '', 'Contacto', '', 'inherit', 'open', 'open', '', '40-revision-v1', '', '', '2015-02-06 16:08:53', '2015-02-06 19:08:53', '', 40, 'http://dev.parsons.app/?p=41', 0, 'revision', '', 0),
(42, 1, '2015-02-06 16:10:09', '2015-02-06 19:10:09', ' ', '', '', 'publish', 'open', 'open', '', '42', '', '', '2016-01-30 20:50:35', '2016-01-30 23:50:35', '', 0, 'http://dev.parsons.app/?p=42', 3, 'nav_menu_item', '', 0),
(50, 1, '2015-02-09 15:51:43', '2015-02-09 18:51:43', 'a:6:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:8:"archivos";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";a:10:{i:0;s:11:"the_content";i:1;s:7:"excerpt";i:2;s:13:"custom_fields";i:3;s:10:"discussion";i:4;s:9:"revisions";i:5;s:6:"format";i:6;s:15:"page_attributes";i:7;s:14:"featured_image";i:8;s:4:"tags";i:9;s:15:"send-trackbacks";}}', 'Foto Galería', 'foto-galeria', 'publish', 'closed', 'closed', '', 'group_54d9016876c3d', '', '', '2015-11-05 23:15:05', '2015-11-06 02:15:05', '', 0, 'http://dev.parsons.app/?post_type=acf-field-group&#038;p=50', 0, 'acf-field-group', '', 0),
(51, 1, '2015-02-09 15:51:43', '2015-02-09 18:51:43', 'a:8:{s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:5:"array";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";}', 'Foto grande galeria', 'foto_grande_galeria', 'publish', 'open', 'open', '', 'field_54d90170737e1', '', '', '2015-02-09 15:51:43', '2015-02-09 18:51:43', '', 50, 'http://dev.parsons.app/?post_type=acf-field&p=51', 0, 'acf-field', '', 0),
(67, 1, '2015-02-09 17:19:02', '2015-02-09 20:19:02', 'a:8:{s:4:"type";s:5:"image";s:12:"instructions";s:15:"Tamaño 226x170";s:8:"required";i:0;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"return_format";s:3:"url";s:12:"preview_size";s:4:"full";s:7:"library";s:3:"all";}', 'Foto pequeña galeria', 'foto_pequena_galeria', 'publish', 'open', 'open', '', 'field_54d915af295b8', '', '', '2015-02-09 17:19:02', '2015-02-09 20:19:02', '', 50, 'http://dev.parsons.app/?post_type=acf-field&p=67', 1, 'acf-field', '', 0),
(72, 1, '2015-02-10 13:07:29', '2015-02-10 16:07:29', '[si-contact-form form=\'3\']', 'Contacto', '', 'inherit', 'open', 'open', '', '40-revision-v1', '', '', '2015-02-10 13:07:29', '2015-02-10 16:07:29', '', 40, 'http://dev.parsons.app/?p=72', 0, 'revision', '', 0),
(82, 1, '2015-02-12 00:01:58', '2015-02-12 03:01:58', '<a href="http://dev.parsons.app/wp-content/uploads/2015/02/revista-hola-carolina-parsons-3.jpg"><img class="aligncenter wp-image-81 size-large" src="http://dev.parsons.app/wp-content/uploads/2015/02/revista-hola-carolina-parsons-3-768x1024.jpg" alt="Carolina, Ema, Rosita se confienzan en revista Hola" width="768" height="1024" /></a>\r\n\r\n3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '3 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2015-02-12 00:01:58', '2015-02-12 03:01:58', '', 24, 'http://dev.parsons.app/?p=82', 0, 'revision', '', 0),
(83, 1, '2015-02-12 00:04:09', '2015-02-12 03:04:09', '<a href="http://dev.parsons.app/wp-content/uploads/2015/02/revista-hola-carolina-parsons-3.jpg"><img class="alignleft wp-image-81 size-full" src="http://dev.parsons.app/wp-content/uploads/2015/02/revista-hola-carolina-parsons-3.jpg" alt="Carolina, Ema, Rosita se confienzan en revista Hola" width="1200" height="1599" /></a>\r\n\r\n3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '3 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2015-02-12 00:04:09', '2015-02-12 03:04:09', '', 24, 'http://dev.parsons.app/?p=83', 0, 'revision', '', 0),
(84, 1, '2015-02-12 00:05:27', '2015-02-12 03:05:27', '&nbsp;\r\n\r\n3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '3 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2015-02-12 00:05:27', '2015-02-12 03:05:27', '', 24, 'http://dev.parsons.app/?p=84', 0, 'revision', '', 0) ;
INSERT INTO `cp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(85, 1, '2015-02-12 00:06:11', '2015-02-12 03:06:11', '3 Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat olutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis.<!--more-->\r\n\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim. Donec pede justo, fringilla vel, aliquet nec, vulputate eget, arcu. In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium. Integer tincidunt. Cras dapibus. Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus.\r\n\r\nPhasellus viverra nulla ut metus varius laoreet. Quisque rutrum. Aenean imperdiet. Etiam ultricies nisi vel augue. Curabitur ullamcorper ultricies nisi. Nam eget dui. Etiam rhoncus. Maecenas tempus, tellus eget condimentum rhoncus, sem quam semper libero, sit amet adipiscing sem neque sed ipsum. Nam quam nunc, blandit vel, luctus pulvinar, hendrerit id, lorem. Maecenas nec odio et ante tincidunt tempus. Donec vitae sapien ut libero venenatis faucibus. Nullam quis ante. Etiam sit amet orci eget eros faucibus tincidunt. Duis leo. Sed fringilla mauris sit amet nibh. Donec sodales sagittis magna. Sed consequat, leo eget bibendum sodales, augue velit cursus nunc, quis gravida magna mi a libero. Fusce vulputate eleifend sapien.\r\n\r\nVestibulum purus quam, scelerisque ut, mollis sed, nonummy id, metus. Nullam accumsan lorem in dui. Cras ultricies mi eu turpis hendrerit fringilla. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; In ac dui quis mi consectetuer lacinia. Nam pretium turpis et arcu. Duis arcu tortor, suscipit eget, imperdiet nec, imperdiet iaculis, ipsum. Sed aliquam ultrices mauris. Integer ante arcu, accumsan a, consectetuer eget, posuere ut, mauris. Praesent adipiscing. Phasellus ullamcorper ipsum rutrum nunc. Nunc nonummy metus. Vestibulum volutpat pretium libero. Cras id dui. Aenean ut eros et nisl sagittis vestibulum. Nullam nulla eros, ultricies sit amet, nonummy id, imperdiet feugiat, pede.\r\n\r\nSed lectus. Donec mollis hendrerit risus. Phasellus nec sem in justo pellentesque facilisis. Etiam imperdiet imperdiet orci. Nunc nec neque. Phasellus leo dolor, tempus non, auctor et, hendrerit quis, nisi. Curabitur ligula sapien, tincidunt non, euismod vitae, posuere imperdiet, leo. Maecenas malesuada. Praesent congue erat at massa. Sed cursus turpis vitae tortor. Donec posuere vulputate arcu. Phasellus accumsan cursus velit. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Sed aliquam, nisi quis porttitor congue, elit erat euismod orci, ac placerat dolor lectus quis orci. Phasellus consectetuer vestibulum elit. Aenean tellus metus, bibendum sed, posuere ac, mattis non, nunc. Vestibulum fringilla pede sit amet augue. In turpis. Pellentesque posuere. Praesent turpis. Aenean posuere, tortor sed cursus feugiat, nunc augue blandit nunc, eu sollicitudin urna dolor sagittis lacus. Donec elit libero, sodales nec, volutpat a, suscipit non, turpis. Nullam sagittis. Suspendisse pulvinar, augue ac venenatis condimentum, sem libero volutpat nibh, nec pellentesque velit pede quis nunc. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce id purus. Ut varius tincidunt libero. Phasellus dolor. Maecenas vestibulum mollis', '3 Sed diam nonummy nibh euismod tincidunt aut laoreet dolore magna', '', 'inherit', 'open', 'open', '', '24-revision-v1', '', '', '2015-02-12 00:06:11', '2015-02-12 03:06:11', '', 24, 'http://dev.parsons.app/?p=85', 0, 'revision', '', 0),
(318, 1, '2015-02-13 08:55:44', '2015-02-13 11:55:44', '', '693x693px', '', 'inherit', 'open', 'open', '', '693x693px', '', '', '2015-02-13 08:55:44', '2015-02-13 11:55:44', '', 21, 'http://dev.parsons.app/wp-content/uploads/2015/02/693x693px.jpg', 0, 'attachment', 'image/jpeg', 0),
(319, 1, '2015-02-13 08:57:09', '2015-02-13 11:57:09', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a>consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<ul>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ul>\r\nLorem ipsum dolor sit amet, <a>consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n<iframe src="https://www.youtube.com/embed/UjUzhHiycjY" width="100%" height="520" frameborder="0" allowfullscreen="allowfullscreen"></iframe>\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n<ol>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ol>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', '', 'trash', 'open', 'open', '', 'lorem-ipsum-dolor-sit-amet-consectetur-adipisicing-elit-sed-do-eiusmod', '', '', '2016-01-30 17:49:04', '2016-01-30 20:49:04', '', 0, 'http://dev.parsons.app/?p=319', 0, 'post', '', 0),
(320, 1, '2015-02-13 08:57:09', '2015-02-13 11:57:09', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a>consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<ul>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ul>\r\nLorem ipsum dolor sit amet, <a>consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n<ol>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ol>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '319-revision-v1', '', '', '2015-02-13 08:57:09', '2015-02-13 11:57:09', '', 319, 'http://dev.parsons.app/?p=320', 0, 'revision', '', 0),
(321, 1, '2015-02-13 09:02:25', '2015-02-13 12:02:25', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a href="">consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<ul>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ul>\r\n\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, <a href="">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n\r\n<iframe width="100%"  height="400px" src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n\r\n\r\n<ol>\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ol>\r\n', 'Consectetur adipisicing elit, sed do eiusmod', '', 'trash', 'open', 'open', '', 'consectetur-adipisicing-elit-sed-do-eiusmod', '', '', '2016-01-19 14:22:53', '2016-01-19 17:22:53', '', 0, 'http://dev.parsons.app/?p=321', 0, 'post', '', 0),
(323, 1, '2015-02-13 09:01:40', '2015-02-13 12:01:40', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a>consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<ul>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ul>\r\nLorem ipsum dolor sit amet, <a>consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n<iframe width="100" src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n<ol>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ol>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '319-revision-v1', '', '', '2015-02-13 09:01:40', '2015-02-13 12:01:40', '', 319, 'http://dev.parsons.app/?p=323', 0, 'revision', '', 0),
(324, 1, '2015-02-13 09:02:25', '2015-02-13 12:02:25', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a href="">consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<ul>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ul>\r\n\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, <a href="">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<iframe width="100%"  src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n\r\n\r\n<ol>\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ol>\r\n', 'Consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '321-revision-v1', '', '', '2015-02-13 09:02:25', '2015-02-13 12:02:25', '', 321, 'http://dev.parsons.app/?p=324', 0, 'revision', '', 0),
(325, 1, '2015-02-13 09:03:57', '2015-02-13 12:03:57', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a>consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<ul>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ul>\r\nLorem ipsum dolor sit amet, <a>consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n<iframe width="693" height="520" src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n<ol>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ol>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '319-revision-v1', '', '', '2015-02-13 09:03:57', '2015-02-13 12:03:57', '', 319, 'http://dev.parsons.app/?p=325', 0, 'revision', '', 0),
(326, 1, '2015-02-13 09:04:58', '2015-02-13 12:04:58', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a href="">consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<ul>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ul>\r\n\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, <a href="">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n\r\n<iframe width="693" height="520" src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n\r\n\r\n<ol>\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ol>\r\n', 'Consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '321-revision-v1', '', '', '2015-02-13 09:04:58', '2015-02-13 12:04:58', '', 321, 'http://dev.parsons.app/?p=326', 0, 'revision', '', 0),
(330, 1, '2015-02-25 14:39:41', '2015-02-25 17:39:41', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a href="">consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<ul>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ul>\r\n\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, <a href="">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n\r\n<iframe width="100%" src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n\r\n\r\n<ol>\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ol>\r\n', 'Consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '321-revision-v1', '', '', '2015-02-25 14:39:41', '2015-02-25 17:39:41', '', 321, 'http://dev.parsons.app/?p=330', 0, 'revision', '', 0),
(331, 1, '2015-02-25 14:40:10', '2015-02-25 17:40:10', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a href="">consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n<ul>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ul>\r\n\r\n\r\n<p>\r\n	Lorem ipsum dolor sit amet, <a href="">consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum. </p>\r\n\r\n\r\n<iframe width="100%"  height="400px" src="https://www.youtube.com/embed/UjUzhHiycjY" frameborder="0" allowfullscreen></iframe>\r\n\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n\r\n\r\n<ol>\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Taza</li>\r\n\r\n	<li>Sarten</li>\r\n\r\n\r\n	<li>Taza</li>\r\n</ol>\r\n', 'Consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '321-revision-v1', '', '', '2015-02-25 14:40:10', '2015-02-25 17:40:10', '', 321, 'http://dev.parsons.app/?p=331', 0, 'revision', '', 0),
(336, 1, '2015-11-05 22:34:55', '2015-11-06 01:34:55', '', 'Carrera', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2015-11-05 22:34:55', '2015-11-06 01:34:55', '', 38, 'http://dev.parsons.app/?p=336', 0, 'revision', '', 0),
(337, 1, '2015-11-05 22:37:32', '2015-11-06 01:37:32', 'Lorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas "Letraset", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.\r\n\r\nLorem Ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estándar de las industrias desde el año 1500, cuando un impresor (N. del T. persona que se dedica a la imprenta) desconocido usó una galería de textos y los mezcló de tal manera que logró hacer un libro de textos especimen. No sólo sobrevivió 500 años, sino que tambien ingresó como texto de relleno en documentos electrónicos, quedando esencialmente igual al original. Fue popularizado en los 60s con la creación de las hojas "Letraset", las cuales contenian pasajes de Lorem Ipsum, y más recientemente con software de autoedición, como por ejemplo Aldus PageMaker, el cual incluye versiones de Lorem Ipsum.\r\n\r\n[gallery link="none" ids="298,300,299,297,296,295"]', 'Carrera', '', 'inherit', 'open', 'open', '', '38-revision-v1', '', '', '2015-11-05 22:37:32', '2015-11-06 01:37:32', '', 38, 'http://dev.parsons.app/?p=337', 0, 'revision', '', 0),
(340, 1, '2015-11-05 22:48:35', '2015-11-06 01:48:35', ' ', '', '', 'publish', 'open', 'open', '', '340', '', '', '2016-01-30 20:50:35', '2016-01-30 23:50:35', '', 0, 'http://dev.parsons.app/?p=340', 2, 'nav_menu_item', '', 0),
(371, 1, '2016-01-19 16:38:40', '2016-01-19 19:38:40', '[gallery size="medium" ids="373,374,375,376,377"]\r\n\r\n&nbsp;\r\n\r\naisuh das asdhjasdjásj  asjdjasldjas´djá ásjdasjdásjd', 'SML', '', 'trash', 'open', 'open', '', 'sml', '', '', '2016-01-30 17:49:04', '2016-01-30 20:49:04', '', 0, 'http://dev.parsons.app/?p=371', 0, 'post', '', 0),
(378, 1, '2016-01-19 16:38:40', '2016-01-19 19:38:40', '[gallery size="medium" ids="373,374,375,376,377"]', 'SML', '', 'inherit', 'open', 'open', '', '371-revision-v1', '', '', '2016-01-19 16:38:40', '2016-01-19 19:38:40', '', 371, 'http://dev.parsons.app/?p=378', 0, 'revision', '', 0),
(379, 1, '2016-01-19 16:44:06', '2016-01-19 19:44:06', '[gallery size="medium" ids="373,374,375,376,377"]\n\n&nbsp;\n\naisuh das asdhjasdjásj  asjdjasldjas´djá ásjdasjdásjd', 'Revista  SML  frances y furdol', '', 'inherit', 'open', 'open', '', '371-autosave-v1', '', '', '2016-01-19 16:44:06', '2016-01-19 19:44:06', '', 371, 'http://dev.parsons.app/?p=379', 0, 'revision', '', 0),
(380, 1, '2016-01-19 16:39:57', '2016-01-19 19:39:57', '[gallery size="medium" ids="373,374,375,376,377"]\r\n\r\n&nbsp;\r\n\r\naisuh das asdhjasdjásj  asjdjasldjas´djá ásjdasjdásjd', 'SML', '', 'inherit', 'open', 'open', '', '371-revision-v1', '', '', '2016-01-19 16:39:57', '2016-01-19 19:39:57', '', 371, 'http://dev.parsons.app/?p=380', 0, 'revision', '', 0),
(382, 1, '2016-01-29 18:38:27', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-29 18:38:27', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?p=382', 0, 'post', '', 0),
(383, 1, '2016-01-30 15:41:58', '2016-01-30 18:41:58', '<h1>Encabezado H1</h1>\r\n<h2>Sub encabezado H2</h2>\r\n<h3>Sub Encabezado H3</h3>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo <a>consectetur adipisicing</a> consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n<ul>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ul>\r\nLorem ipsum dolor sit amet, <a>consectetur adipisicing</a> elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in <strong>voluptate</strong> velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat <i>cupidatat non proident,</i> sunt in culpa qui officia deserunt mollit anim id est laborum.\r\n\r\n<iframe src="https://www.youtube.com/embed/UjUzhHiycjY" width="100%" height="520" frameborder="0" allowfullscreen="allowfullscreen"></iframe>\r\n<blockquote>tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo</blockquote>\r\n<ol>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n	<li>Taza</li>\r\n	<li>Sarten</li>\r\n	<li>Taza</li>\r\n</ol>', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod', '', 'inherit', 'open', 'open', '', '319-revision-v1', '', '', '2016-01-30 15:41:58', '2016-01-30 18:41:58', '', 319, 'http://dev.parsons.app/?p=383', 0, 'revision', '', 0),
(384, 1, '2016-01-30 17:46:05', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-30 17:46:05', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?post_type=archivos&p=384', 0, 'archivos', '', 0),
(385, 1, '2016-01-30 17:50:13', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-30 17:50:13', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?post_type=archivos&p=385', 0, 'archivos', '', 0),
(386, 1, '2016-01-30 18:00:15', '2016-01-30 21:00:15', 'Portadas Antilope', 'Antilope', '', 'publish', 'open', 'open', '', 'antilope', '', '', '2016-01-30 18:00:15', '2016-01-30 21:00:15', '', 0, 'http://dev.parsons.app/?post_type=ht_gallery_post&#038;p=386', 0, 'ht_gallery_post', '', 0),
(387, 1, '2016-01-30 17:57:51', '2016-01-30 20:57:51', '', 'portada_revista_antilope_fotografo_simon_pais_carolina_parsons', '', 'inherit', 'open', 'open', '', 'portada_revista_antilope_fotografo_simon_pais_carolina_parsons', '', '', '2016-01-30 17:57:51', '2016-01-30 20:57:51', '', 386, 'http://dev.parsons.app/wp-content/uploads/2016/01/portada_revista_antilope_fotografo_simon_pais_carolina_parsons.jpg', 0, 'attachment', 'image/jpeg', 0),
(388, 1, '2016-01-30 17:57:56', '2016-01-30 20:57:56', '', 'revista_antilope_entrevista_blood_sugar_baby_carolina_parsons', '', 'inherit', 'open', 'open', '', 'revista_antilope_entrevista_blood_sugar_baby_carolina_parsons', '', '', '2016-01-30 17:57:56', '2016-01-30 20:57:56', '', 386, 'http://dev.parsons.app/wp-content/uploads/2016/01/revista_antilope_entrevista_blood_sugar_baby_carolina_parsons.jpg', 0, 'attachment', 'image/jpeg', 0),
(389, 1, '2016-01-30 17:58:01', '2016-01-30 20:58:01', '', 'revista_antilope_entrevista_carolina_parsons', '', 'inherit', 'open', 'open', '', 'revista_antilope_entrevista_carolina_parsons', '', '', '2016-01-30 17:58:01', '2016-01-30 20:58:01', '', 386, 'http://dev.parsons.app/wp-content/uploads/2016/01/revista_antilope_entrevista_carolina_parsons.jpg', 0, 'attachment', 'image/jpeg', 0),
(390, 1, '2016-01-30 17:58:06', '2016-01-30 20:58:06', '', 'revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons', '', 'inherit', 'open', 'open', '', 'revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons', '', '', '2016-01-30 17:58:06', '2016-01-30 20:58:06', '', 386, 'http://dev.parsons.app/wp-content/uploads/2016/01/revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons.jpg', 0, 'attachment', 'image/jpeg', 0),
(391, 1, '2016-01-30 17:58:12', '2016-01-30 20:58:12', '', 'revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2', '', 'inherit', 'open', 'open', '', 'revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2', '', '', '2016-01-30 17:58:12', '2016-01-30 20:58:12', '', 386, 'http://dev.parsons.app/wp-content/uploads/2016/01/revista_antilope_entrevista_fotografo_simon_pais_carolina_parsons2.jpg', 0, 'attachment', 'image/jpeg', 0),
(392, 1, '2016-01-30 18:02:38', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-30 18:02:38', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?post_type=archivos&p=392', 0, 'archivos', '', 0),
(393, 1, '2016-01-30 18:04:12', '2016-01-30 21:04:12', '[ht_gallery id="386" name="Antilope"  columns="1"]', 'Archivos2', '', 'publish', 'open', 'open', '', 'archivos2', '', '', '2016-01-30 18:04:12', '2016-01-30 21:04:12', '', 0, 'http://dev.parsons.app/?page_id=393', 0, 'page', '', 0),
(394, 1, '2016-01-30 18:04:12', '2016-01-30 21:04:12', '[ht_gallery id="386" name="Antilope"  columns="1"]', 'Archivos2', '', 'inherit', 'open', 'open', '', '393-revision-v1', '', '', '2016-01-30 18:04:12', '2016-01-30 21:04:12', '', 393, 'http://dev.parsons.app/?p=394', 0, 'revision', '', 0),
(395, 1, '2016-01-30 18:04:46', '0000-00-00 00:00:00', '', 'Heroic Gallery', '', 'draft', 'open', 'open', '', '', '', '', '2016-01-30 18:04:46', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?p=395', 1, 'nav_menu_item', '', 0),
(397, 1, '2016-01-30 18:05:02', '0000-00-00 00:00:00', '', 'Heroic Gallery', '', 'draft', 'open', 'open', '', '', '', '', '2016-01-30 18:05:02', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?p=397', 1, 'nav_menu_item', '', 0),
(399, 1, '2016-01-30 18:17:18', '2016-01-30 21:17:18', '', 'Editorial', '', 'publish', 'closed', 'closed', '', 'editorial', '', '', '2016-01-30 19:03:33', '2016-01-30 22:03:33', '', 0, 'http://dev.parsons.app/?post_type=archivos&#038;p=399', 0, 'archivos', '', 0),
(400, 1, '2016-01-30 18:17:04', '2016-01-30 21:17:04', '', 'blog_danilo_brasil_1_carolina_parsons', '', 'inherit', 'open', 'open', '', 'blog_danilo_brasil_1_carolina_parsons', '', '', '2016-01-30 18:17:04', '2016-01-30 21:17:04', '', 399, 'http://dev.parsons.app/wp-content/uploads/blog_danilo_brasil_1_carolina_parsons.jpg', 0, 'attachment', 'image/jpeg', 0),
(401, 1, '2016-01-30 18:34:48', '2016-01-30 21:34:48', 'El pasaje estándar Lorem Ipsum, usado desde el año 1500.\r\n\r\n"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\nSección 1.10.32 de "de Finibus Bonorum et Malorum", escrito por Cicero en el 45 antes de Cristo\r\n\r\n"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\nTraducción hecha por H. Rackham en 1914\r\n\r\n[ht_gallery id="386" name="Antilope"  columns="3"]\r\n\r\n"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"', 'Hola Mundo!', '', 'publish', 'open', 'open', '', 'hola-mundo', '', '', '2016-01-30 18:34:48', '2016-01-30 21:34:48', '', 0, 'http://dev.parsons.app/?p=401', 0, 'post', '', 0),
(402, 1, '2016-01-30 18:34:21', '2016-01-30 21:34:21', '', '575', '', 'inherit', 'open', 'open', '', '575', '', '', '2016-01-30 18:34:21', '2016-01-30 21:34:21', '', 401, 'http://dev.parsons.app/wp-content/uploads/575.jpg', 0, 'attachment', 'image/jpeg', 0),
(403, 1, '2016-01-30 18:34:48', '2016-01-30 21:34:48', 'El pasaje estándar Lorem Ipsum, usado desde el año 1500.\r\n\r\n"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\nSección 1.10.32 de "de Finibus Bonorum et Malorum", escrito por Cicero en el 45 antes de Cristo\r\n\r\n"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\nTraducción hecha por H. Rackham en 1914\r\n\r\n[ht_gallery id="386" name="Antilope"  columns="3"]\r\n\r\n"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"', 'Hola Mundo!', '', 'inherit', 'open', 'open', '', '401-revision-v1', '', '', '2016-01-30 18:34:48', '2016-01-30 21:34:48', '', 401, 'http://dev.parsons.app/?p=403', 0, 'revision', '', 0),
(404, 1, '2016-01-30 18:57:15', '2016-01-30 21:57:15', '', 'Recortes', '', 'publish', 'closed', 'closed', '', 'recortes', '', '', '2016-01-30 18:57:15', '2016-01-30 21:57:15', '', 0, 'http://dev.parsons.app/?post_type=archivos&#038;p=404', 0, 'archivos', '', 0),
(405, 1, '2016-01-30 18:55:06', '2016-01-30 21:55:06', '', 'editorial', '', 'inherit', 'open', 'open', '', 'editorial-2', '', '', '2016-01-30 18:55:06', '2016-01-30 21:55:06', '', 404, 'http://dev.parsons.app/wp-content/uploads/editorial.jpg', 0, 'attachment', 'image/jpeg', 0),
(406, 1, '2016-01-30 18:55:09', '2016-01-30 21:55:09', '', 'portadas', '', 'inherit', 'open', 'open', '', 'portadas-2', '', '', '2016-01-30 18:55:09', '2016-01-30 21:55:09', '', 404, 'http://dev.parsons.app/wp-content/uploads/portadas.jpg', 0, 'attachment', 'image/jpeg', 0),
(407, 1, '2016-01-30 18:55:11', '2016-01-30 21:55:11', '', 'prensa', '', 'inherit', 'open', 'open', '', 'prensa', '', '', '2016-01-30 18:55:11', '2016-01-30 21:55:11', '', 404, 'http://dev.parsons.app/wp-content/uploads/prensa.jpg', 0, 'attachment', 'image/jpeg', 0),
(408, 1, '2016-01-30 18:55:13', '2016-01-30 21:55:13', '', 'publicidad', '', 'inherit', 'open', 'open', '', 'publicidad', '', '', '2016-01-30 18:55:13', '2016-01-30 21:55:13', '', 404, 'http://dev.parsons.app/wp-content/uploads/publicidad.jpg', 0, 'attachment', 'image/jpeg', 0),
(409, 1, '2016-01-30 18:55:15', '2016-01-30 21:55:15', '', 'recortes', '', 'inherit', 'open', 'open', '', 'recortes', '', '', '2016-01-30 18:55:15', '2016-01-30 21:55:15', '', 404, 'http://dev.parsons.app/wp-content/uploads/recortes.jpg', 0, 'attachment', 'image/jpeg', 0),
(410, 1, '2016-01-30 19:00:47', '2016-01-30 22:00:47', '', 'Editorial', '', 'inherit', 'open', 'open', '', '399-autosave-v1', '', '', '2016-01-30 19:00:47', '2016-01-30 22:00:47', '', 399, 'http://dev.parsons.app/?p=410', 0, 'revision', '', 0),
(411, 1, '2016-01-30 19:02:18', '2016-01-30 22:02:18', '', 'Portadas', '', 'publish', 'closed', 'closed', '', 'portadas-2', '', '', '2016-01-30 19:02:18', '2016-01-30 22:02:18', '', 0, 'http://dev.parsons.app/?post_type=archivos&#038;p=411', 0, 'archivos', '', 0),
(412, 1, '2016-01-30 19:05:52', '2016-01-30 22:05:52', '', 'Prensa', '', 'publish', 'closed', 'closed', '', 'prensa', '', '', '2016-01-30 19:05:52', '2016-01-30 22:05:52', '', 0, 'http://dev.parsons.app/?post_type=archivos&#038;p=412', 0, 'archivos', '', 0),
(413, 1, '2016-01-30 19:06:31', '2016-01-30 22:06:31', '', 'Publicidad', '', 'trash', 'closed', 'closed', '', 'publicidad', '', '', '2016-01-30 19:08:50', '2016-01-30 22:08:50', '', 0, 'http://dev.parsons.app/?post_type=archivos&#038;p=413', 0, 'archivos', '', 0),
(414, 1, '2016-01-30 19:05:25', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-30 19:05:25', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?post_type=archivos&p=414', 0, 'archivos', '', 0),
(415, 1, '2016-01-30 19:11:31', '0000-00-00 00:00:00', '', 'Borrador automático', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-01-30 19:11:31', '0000-00-00 00:00:00', '', 0, 'http://dev.parsons.app/?p=415', 0, 'post', '', 0),
(416, 1, '2016-01-30 19:13:47', '2016-01-30 22:13:47', '', 'Publicidad', '', 'publish', 'closed', 'closed', '', 'publicidad-2', '', '', '2016-01-30 19:13:47', '2016-01-30 22:13:47', '', 0, 'http://dev.parsons.app/?post_type=archivos&#038;p=416', 0, 'archivos', '', 0),
(417, 1, '2016-01-30 19:13:33', '2016-01-30 22:13:33', '', 'publicidad', '', 'inherit', 'open', 'open', '', 'publicidad-2', '', '', '2016-01-30 19:13:33', '2016-01-30 22:13:33', '', 416, 'http://dev.parsons.app/wp-content/uploads/publicidad1.jpg', 0, 'attachment', 'image/jpeg', 0),
(418, 1, '2016-01-30 20:19:27', '2016-01-30 23:19:27', 'El pasaje estándar Lorem Ipsum, usado desde el año 1500.\r\n\r\n"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\nSección 1.10.32 de "de Finibus Bonorum et Malorum", escrito por Cicero en el 45 antes de Cristo\r\n\r\n"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\nTraducción hecha por H. Rackham en 1914\r\n\r\n[gallery ids="417,409,391,400,390,407,405,387"]\r\n\r\n"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"', 'Les deseo una fantastica semana', '', 'publish', 'open', 'open', '', 'hola-mundo-2', '', '', '2016-01-30 20:19:27', '2016-01-30 23:19:27', '', 0, 'http://dev.parsons.app/?p=418', 0, 'post', '', 0),
(419, 1, '2016-01-30 20:19:27', '2016-01-30 23:19:27', 'El pasaje estándar Lorem Ipsum, usado desde el año 1500.\r\n\r\n"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."\r\nSección 1.10.32 de "de Finibus Bonorum et Malorum", escrito por Cicero en el 45 antes de Cristo\r\n\r\n"Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?"\r\nTraducción hecha por H. Rackham en 1914\r\n\r\n[gallery ids="417,409,391,400,390,407,405,387"]\r\n\r\n"But I must explain to you how all this mistaken idea of denouncing pleasure and praising pain was born and I will give you a complete account of the system, and expound the actual teachings of the great explorer of the truth, the master-builder of human happiness. No one rejects, dislikes, or avoids pleasure itself, because it is pleasure, but because those who do not know how to pursue pleasure rationally encounter consequences that are extremely painful. Nor again is there anyone who loves or pursues or desires to obtain pain of itself, because it is pain, but because occasionally circumstances occur in which toil and pain can procure him some great pleasure. To take a trivial example, which of us ever undertakes laborious physical exercise, except to obtain some advantage from it? But who has any right to find fault with a man who chooses to enjoy a pleasure that has no annoying consequences, or one who avoids a pain that produces no resultant pleasure?"', 'Les deseo una fantastica semana', '', 'inherit', 'open', 'open', '', '418-revision-v1', '', '', '2016-01-30 20:19:27', '2016-01-30 23:19:27', '', 418, 'http://dev.parsons.app/?p=419', 0, 'revision', '', 0) ;

#
# End of data contents of table `cp_posts`
# --------------------------------------------------------



#
# Delete any existing table `cp_term_relationships`
#

DROP TABLE IF EXISTS `cp_term_relationships`;


#
# Table structure of table `cp_term_relationships`
#

CREATE TABLE `cp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_term_relationships`
#
INSERT INTO `cp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(16, 2, 0),
(16, 4, 0),
(21, 2, 0),
(21, 3, 0),
(24, 2, 0),
(24, 5, 0),
(30, 7, 0),
(42, 7, 0),
(319, 2, 0),
(319, 3, 0),
(319, 4, 0),
(319, 5, 0),
(319, 6, 0),
(321, 2, 0),
(321, 3, 0),
(321, 4, 0),
(321, 5, 0),
(321, 6, 0),
(340, 7, 0),
(371, 2, 0),
(371, 43, 0),
(386, 45, 0),
(386, 46, 0),
(399, 36, 0),
(399, 37, 0),
(401, 2, 0),
(401, 5, 0),
(404, 36, 0),
(404, 47, 0),
(411, 36, 0),
(411, 39, 0),
(412, 36, 0),
(413, 36, 0),
(413, 42, 0),
(416, 36, 0),
(416, 42, 0),
(418, 2, 0),
(418, 5, 0) ;

#
# End of data contents of table `cp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `cp_term_taxonomy`
#

DROP TABLE IF EXISTS `cp_term_taxonomy`;


#
# Table structure of table `cp_term_taxonomy`
#

CREATE TABLE `cp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_term_taxonomy`
#
INSERT INTO `cp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'category', '', 0, 2),
(3, 3, 'category', '', 2, 0),
(4, 4, 'category', '', 2, 0),
(5, 5, 'category', '', 2, 2),
(6, 6, 'category', '', 2, 0),
(7, 7, 'nav_menu', '', 0, 3),
(36, 36, 'category', '', 0, 5),
(37, 37, 'category', '', 36, 1),
(39, 39, 'category', '', 36, 1),
(42, 42, 'category', '', 36, 1),
(43, 43, 'category', '', 2, 0),
(44, 44, 'category', '', 39, 0),
(45, 45, 'ht_gallery_category', '', 0, 1),
(46, 46, 'ht_gallery_category', '', 45, 1),
(47, 47, 'category', '', 36, 1) ;

#
# End of data contents of table `cp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `cp_terms`
#

DROP TABLE IF EXISTS `cp_terms`;


#
# Table structure of table `cp_terms`
#

CREATE TABLE `cp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_terms`
#
INSERT INTO `cp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Blog', 'blog', 0),
(3, 'La moda al día', 'la-moda-al-dia', 0),
(4, 'Bitácora', 'bitacora', 0),
(5, 'Eventos', 'eventos', 0),
(6, 'Mis viajes', 'mis-viajes', 0),
(7, 'Menú Principal', 'menu-principal', 0),
(36, 'Archivos', 'archivos', 0),
(37, 'Editorial', 'editorial', 0),
(39, 'Portadas', 'portadas', 0),
(42, 'Publicidad', 'publicidad', 0),
(43, 'Portadas', 'portadas-blog', 0),
(44, 'Revista YA', 'revista-ya', 0),
(45, 'Archivos', 'archivos', 0),
(46, 'Antilope', 'antilope', 0),
(47, 'Recortes', 'recortes', 0) ;

#
# End of data contents of table `cp_terms`
# --------------------------------------------------------



#
# Delete any existing table `cp_usermeta`
#

DROP TABLE IF EXISTS `cp_usermeta`;


#
# Table structure of table `cp_usermeta`
#

CREATE TABLE `cp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_usermeta`
#
INSERT INTO `cp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'admin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'cp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'cp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp360_locks,wp390_widgets,wp410_dfw'),
(13, 1, 'show_welcome_panel', '0'),
(14, 1, 'session_tokens', 'a:4:{s:64:"464936e12258701fcf9efe63d6ba0c44d222bd837db14543f42c0492876a1657";a:4:{s:10:"expiration";i:1454276302;s:2:"ip";s:14:"190.45.224.244";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36";s:5:"login";i:1454103502;}s:64:"ebe9d4fd4358aa48a34ec51f1b67e829579ebac4893aa3096b5ccccd76d16863";a:4:{s:10:"expiration";i:1454289039;s:2:"ip";s:12:"190.44.61.46";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:44.0) Gecko/20100101 Firefox/44.0";s:5:"login";i:1454116239;}s:64:"ceb31029609a83153520374f10d441690788b75310be355ce7d6c1573071b82a";a:4:{s:10:"expiration";i:1454351081;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:44.0) Gecko/20100101 Firefox/44.0";s:5:"login";i:1454178281;}s:64:"ab2ff317bfe3c9406e458cea2ca76c5f85703c693fbddbb6b1b68a381b869f85";a:4:{s:10:"expiration";i:1454379232;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.97 Safari/537.36";s:5:"login";i:1454206432;}}'),
(15, 1, 'cp_dashboard_quick_press_last_post_id', '382'),
(16, 1, 'cp_user-settings', 'libraryContent=browse&posts_list_mode=list&editor=html'),
(17, 1, 'cp_user-settings-time', '1454186750'),
(18, 1, 'closedpostboxes_editorial', 'a:0:{}'),
(19, 1, 'metaboxhidden_editorial', 'a:4:{i:0;s:16:"tagsdiv-post_tag";i:1;s:12:"postimagediv";i:2;s:23:"acf-group_54d3cee943294";i:3;s:7:"slugdiv";}'),
(20, 1, 'nav_menu_recently_edited', '7'),
(21, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(22, 1, 'metaboxhidden_nav-menus', 'a:4:{i:0;s:8:"add-post";i:1;s:13:"add-editorial";i:2;s:12:"add-post_tag";i:3;s:15:"add-post_format";}'),
(23, 1, 'cp_media_library_mode', 'list'),
(24, 1, 'closedpostboxes_archivos', 'a:1:{i:0;s:13:"setcustommeta";}'),
(25, 1, 'metaboxhidden_archivos', 'a:3:{i:0;s:16:"tagsdiv-post_tag";i:1;s:23:"acf-group_54d3cee943294";i:2;s:7:"slugdiv";}'),
(26, 1, '_ht_gallery_view386', 'stamps'),
(27, 1, 'meta-box-order_archivos', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:38:"submitdiv,categorydiv,tagsdiv-post_tag";s:6:"normal";s:69:"acf-group_54d9016876c3d,acf-group_54d3cee943294,slugdiv,setcustommeta";s:8:"advanced";s:0:"";}'),
(28, 1, 'screen_layout_archivos', '2') ;

#
# End of data contents of table `cp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `cp_users`
#

DROP TABLE IF EXISTS `cp_users`;


#
# Table structure of table `cp_users`
#

CREATE TABLE `cp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(64) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


#
# Data contents of table `cp_users`
#
INSERT INTO `cp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'admin', '$P$BWdd534iH3GmBPFzX23eM1ZfdzedRa/', 'admin', 'cristian@rotrer.com', '', '2015-02-05 12:57:52', '', 0, 'admin') ;

#
# End of data contents of table `cp_users`
# --------------------------------------------------------

#
# Add constraints back in
#

